-- GI-275 HSI Lua file for Air Manager (MSFS2020, Canvas API)
-- ...[previous comments omitted for brevity]...

local W, H = 320, 320

local TEST_MODE = false--true

local white = "white"
local cyan = "#00eaff"
local magenta = "#e049b0"
local green = "#00ff00"
local grey = "#555555"

local hdg_selected = false
local crs_selected = false

local heading = 0
local hdg_bug = 0
local course = 0
local track = 0        -- <<<<<<<<<<< NEW: Aircraft track, for magenta triangle
local source = "VOR 1"
local course_color = green
local cdi_deflection = 0
local cdi_flag = 1 -- 1=TO, 2=FROM
local nav_gps = true
local mag_var = 11

local dis = 0.0      -- Distance to waypoint (nautical miles)
local ete = "00:00"  -- Estimated time enroute (MM:SS)
local nav_mode = ""  -- Navigation mode ("ENR", "LPV", etc.)

-- GS/GP logic
local gs_active = false
local gs_label = ""
local gs_deflection = 0      -- -2 to +2, 0=center, negative=below, positive=above
local gs_valid = false
local gp_active = false
local gp_valid = false

-- Single variable to control all vertical deviation X position
local GS_CDI_X = 250
local GS_CDI_Y = 80
local GS_CDI_W = 23
local GS_CDI_H = 150

local compass_img = img_add("compass card.png", 15, 10, 288, 287)
local layer2_img = img_add("Gi-275 HSI layer 2.png", 0, 0, 320, 320)
local heading_bug_img = img_add("Gi-275 bug.png", 0, 0, 25, 20)
local vert_cdi_img = img_add("CDI.png", GS_CDI_X, GS_CDI_Y, GS_CDI_W, GS_CDI_H)
visible(vert_cdi_img, false)

function heading_to_text(val)
    val = math.floor(val + 0.5) % 360
    return string.format("%03d", val)
end

function draw_track_triangle(cx, cy, radius, heading, track)
    -- Draw a small magenta triangle indicating track above compass card
    -- Place over the compass row, above the card
    local rel_track = (track - heading + 360) % 360
    local track_angle = math.rad(rel_track - 90)
    local tri_radius = radius + 20
    local tri_len = 18    -- length of triangle
    local tri_wid = 12    -- width of triangle at base

    -- Triangle tip (pointing at track)
    local tip_x = cx + tri_radius * math.cos(track_angle)
    local tip_y = cy + tri_radius * math.sin(track_angle)

    -- Triangle base corners (perpendicular to track direction)
    local perp_ang = track_angle + math.pi / 2
    local base_x = cx + (tri_radius - tri_len) * math.cos(track_angle)
    local base_y = cy + (tri_radius - tri_len) * math.sin(track_angle)
    local base1_x = base_x - tri_wid/2 * math.cos(perp_ang)
    local base1_y = base_y - tri_wid/2 * math.sin(perp_ang)
    local base2_x = base_x + tri_wid/2 * math.cos(perp_ang)
    local base2_y = base_y + tri_wid/2 * math.sin(perp_ang)
    _triangle(tip_x, tip_y, base1_x, base1_y, base2_x, base2_y)
    _fill(magenta)
end

function draw_gs_gp_cdi()

    if not gs_active or not gs_valid then return end

    local bar_x = GS_CDI_X + GS_CDI_W / 2
    local bar_top = GS_CDI_Y + 14
    local bar_bottom = GS_CDI_Y + GS_CDI_H - 10
    local cdi_range = 2

    local pixel_per_deflect = (bar_bottom - bar_top) / (cdi_range * 2)
    local zero_y = ((bar_top + bar_bottom) / 2)
    local dot_y = zero_y - gs_deflection * pixel_per_deflect

    -- --- Draw GS/GP/VNAV grey box and colored letter ---
    local box_w, box_h = 24, 22
    local box_x = bar_x - box_w / 2
    local box_y = GS_CDI_Y - 20

    _rect(box_x, box_y, box_w, box_h, 6)
    _fill(grey)

    local mode_char, mode_color
    if gs_label == "GS" then
        mode_char = "G"
        mode_color = green
    elseif gs_label == "GP" then
        mode_char = "G"
        mode_color = magenta
    elseif gs_label == "VNAV" then
        mode_char = "V"
        mode_color = magenta
    else
        mode_char = "?"
        mode_color = white
    end

    _txt(mode_char, "size:18; font:arimo_bold.ttf; color:"..mode_color.."; align:center", box_x+5, box_y+2, box_w, box_h-4)

    local label_color = (gs_label == "GP" or gs_label == "VNAV") and magenta or green
    _circle(bar_x, dot_y, 8)
    _fill(label_color)
    _stroke("black", 2)
end

function clamp(val, min, max)
    if val < min then return min end
    if val > max then return max end
    return val
end

function draw_hsi()
    local cx, cy = W/2, H/2
    local radius = 125

    -- Shift CDI center up by 10 pixels
    local cdi_cx, cdi_cy = cx, cy - 10

    -- Compass card
    local img_rotation = -(heading)
    img_move(compass_img, 15, 10, 288, 287)
    img_rotate(compass_img, img_rotation)

    -- TRACK TRIANGLE (magenta, above compass row)
    draw_track_triangle(cx, cy, radius, heading, track)

    -- CDI needle logic
    local rel_course = (course - heading + 360) % 360
    local course_rad = math.rad(rel_course - 90)
    local cdi_angle = course_rad
    local cdi_max_deflect = 2
    local cdi_dot_spacing = 22
    local cdi_length_top = 80
    local cdi_length_bottom = -55

    local cx_cdi_center = cdi_cx
    local cy_cdi_center = cy
    local cdi_top_x = cx_cdi_center + cdi_length_top * math.cos(cdi_angle)
    local cdi_top_y = cy_cdi_center + cdi_length_top * math.sin(cdi_angle)
    local cdi_bottom_x = cx_cdi_center - cdi_length_bottom * math.cos(cdi_angle)
    local cdi_bottom_y = cy_cdi_center - cdi_length_bottom * math.sin(cdi_angle)

    -- Main CDI needle (centered)
    _move_to(cdi_bottom_x, cdi_bottom_y)
    _line_to(cdi_top_x, cdi_top_y)
    _stroke(course_color, 6)

    -- Mirrored needle
    local secondary_offset = cdi_length_top + math.abs(cdi_length_bottom)
    local sec_cx = cx_cdi_center - secondary_offset * math.cos(cdi_angle)
    local sec_cy = cy_cdi_center - secondary_offset * math.sin(cdi_angle)
    local sec_top_x = sec_cx + cdi_length_top * math.cos(cdi_angle)
    local sec_top_y = sec_cy + cdi_length_top * math.sin(cdi_angle)
    local sec_bottom_x = sec_cx - cdi_length_bottom * math.cos(cdi_angle)
    local sec_bottom_y = sec_cy - cdi_length_bottom * math.sin(cdi_angle)
    _move_to(sec_bottom_x, sec_bottom_y)
    _line_to(sec_top_x, sec_top_y)
    _stroke(course_color, 6)

    -- Deviation bar (confined CDI deflection)
    local deviation_dot = clamp(cdi_deflection, -cdi_max_deflect, cdi_max_deflect)
    local bar_len = 80
    local bar_wid = 5
    local bar_cx = cdi_cx + cdi_dot_spacing * deviation_dot * math.cos(cdi_angle + math.pi/2)
    local bar_cy = cy + cdi_dot_spacing * deviation_dot * math.sin(cdi_angle + math.pi/2)
    local bar_x1 = bar_cx - bar_len/2 * math.cos(cdi_angle)
    local bar_y1 = bar_cy - bar_len/2 * math.sin(cdi_angle)
    local bar_x2 = bar_cx + bar_len/2 * math.cos(cdi_angle)
    local bar_y2 = bar_cy + bar_len/2 * math.sin(cdi_angle)
    _move_to(bar_x1, bar_y1)
    _line_to(bar_x2, bar_y2)
    _stroke(course_color, bar_wid)

    draw_top_triangle(cx_cdi_center, cy_cdi_center, cdi_angle, cdi_length_top, course_color)

    -- TO/FROM triangle
    local tri_len = 16
    local tri_wid = 12
    local tri_angle = cdi_angle
    local tri_offset = 36
    local base_x, base_y, tip_x, tip_y

    if cdi_flag == 1 then
        base_x = cx_cdi_center + tri_offset * math.cos(tri_angle)
        base_y = cy_cdi_center + tri_offset * math.sin(tri_angle)
        tip_x = base_x + tri_len * math.cos(tri_angle)
        tip_y = base_y + tri_len * math.sin(tri_angle)
    else
        base_x = cx_cdi_center - tri_offset * math.cos(tri_angle)
        base_y = cy_cdi_center - tri_offset * math.sin(cdi_angle)
        tip_x = base_x - tri_len * math.cos(tri_angle)
        tip_y = base_y - tri_len * math.sin(tri_angle)
    end

    local perp_ang = tri_angle + math.pi / 2
    local base1_x = base_x - tri_wid/2 * math.cos(perp_ang)
    local base1_y = base_y - tri_wid/2 * math.sin(perp_ang)
    local base2_x = base_x + tri_wid/2 * math.cos(perp_ang)
    local base2_y = base_y + tri_wid/2 * math.sin(perp_ang)
    _triangle(tip_x, tip_y, base1_x, base1_y, base2_x, base2_y)
    _fill(course_color)

    -- CDI dots (centered vertically)
    for dot = -cdi_max_deflect, cdi_max_deflect do
        local dx = cdi_cx + cdi_dot_spacing * dot * math.cos(cdi_angle + math.pi/2)
        local dy = cy + cdi_dot_spacing * dot * math.sin(cdi_angle + math.pi/2)
        _circle(dx, dy, 6)
        _fill(white)
        _stroke("black", 2)
    end

    -- Distance and ETE readout (bottom left)
    _txt("DIS:", "size:15; font:arimo_bold.ttf; color:white; align:right", 90, 190, 60, 22)
    _txt(string.format("%.1f", dis), "size:15; font:arimo_bold.ttf; color:"..magenta.."; align:left", 120, 190, 60, 22)
    _txt("ETE:", "size:15; font:arimo_bold.ttf; color:white; align:right", 170, 190, 60, 22)
    _txt(ete, "size:16; font:arimo_bold.ttf; color:"..magenta.."; align:left", 200, 190, 60, 22)

    _txt(source, "size:18; font:arimo_bold.ttf; color:"..course_color.."; align:center", cx-70, 100, 96, 28)
    _txt(nav_mode, "size:18; font:arimo_bold.ttf; color:green; align:left", cx+35, 100, 60, 28)

    img_move(layer2_img, 0, 0, 320, 320)

    -- HDG bug
    local rel_hdg_bug = (hdg_bug - heading + 360) % 360
    local hdg_angle = math.rad(rel_hdg_bug - 90)
    local bug_radius = radius + 10
    local bug_x = cx + bug_radius * math.cos(hdg_angle) - 12.5
    local bug_y = cy + bug_radius * math.sin(hdg_angle) - 15
    img_move(heading_bug_img, bug_x, bug_y, 25, 20)
    img_rotate(heading_bug_img, rel_hdg_bug)

    -- HDG/CRS text boxes
    local hdg_box_x, hdg_box_y, hdg_box_w, hdg_box_h = 86, 232, 38, 33
    if hdg_selected then
        _rect(hdg_box_x-3, hdg_box_y-3, hdg_box_w+6, hdg_box_h+6, 7)
        _stroke(cyan, 4)
    end
    _txt(heading_to_text(hdg_bug).."°", "size:20; font:arimo_bold.ttf; color:"..cyan.."; align:center", hdg_box_x, hdg_box_y+14, hdg_box_w, 18)

    local crs_box_x, crs_box_y, crs_box_w, crs_box_h = 198, 232, 38, 33
    if crs_selected then
        _rect(crs_box_x-3, crs_box_y-3, crs_box_w+6, crs_box_h+6, 7)
        _stroke(green, 4)
    end
    _txt(heading_to_text(course).."°", "size:20; font:arimo_bold.ttf; color:"..course_color.."; align:center", crs_box_x, crs_box_y+14, crs_box_w, 18)

    -- Current heading text
    local heading_num = heading_to_text(heading)
    local heading_str = heading_num
    _txt(heading_str.."°", "size:26; font:arimo_bold.ttf; color:white; align:center", cx-20, 50, 72, 36)

    img_add("Gi-275 bezel.png", 0, 0, 320, 320)

    draw_gs_gp_cdi()
end

function draw_top_triangle(cx_cdi_center, cy_cdi_center, cdi_angle, cdi_length_top, color)
    local tri_len = 18
    local tri_wid = 14
    local top_x = cx_cdi_center + cdi_length_top * math.cos(cdi_angle)
    local top_y = cy_cdi_center + cdi_length_top * math.sin(cdi_angle)
    local tip_x = top_x + tri_len * math.cos(cdi_angle)
    local tip_y = top_y + tri_len * math.sin(cdi_angle)
    local perp_ang = cdi_angle + math.pi / 2
    local base1_x = top_x - tri_wid/2 * math.cos(perp_ang)
    local base1_y = top_y - tri_wid/2 * math.sin(perp_ang)
    local base2_x = top_x + tri_wid/2 * math.cos(perp_ang)
    local base2_y = top_y + tri_wid/2 * math.sin(perp_ang)
    _triangle(tip_x, tip_y, base1_x, base1_y, base2_x, base2_y)
    _fill(color)
end

canvas_id = canvas_add(0, 0, W, H, function() draw_hsi() end)

function redraw()
    canvas_draw(canvas_id, function() draw_hsi() end)
end

function hdg_pressed()
    hdg_selected = true
    crs_selected = false
    redraw()
end

function crs_pressed()
    crs_selected = true
    hdg_selected = false
    redraw()
end

function dial_in(direction)
    if hdg_selected then
        if direction == 1 then
            fs2020_event("HEADING_BUG_INC")
        else
            fs2020_event("HEADING_BUG_DEC")
        end
        --if direction == 1 then hdg_bug = (hdg_bug + 1) % 360
        --elseif direction == -1 then hdg_bug = (hdg_bug - 1 + 360) % 360 end
    elseif crs_selected then
        if direction == 1 then
            fs2020_event("VOR1_OBI_INC")
        else
            fs2020_event("VOR1_OBI_DEC")
        end
        --if direction == 1 then course = (course + 1) % 360
        --elseif direction == -1 then course = (course - 1 + 360) % 360 end
    end
    redraw()
end

function dial_out(direction)
    -- For future expansion
end

function button_pressed()
    print("button")
end

-- Utility: map MSFS nav mode integer to text
function get_nav_mode_text(mode_int)
    local modes = {
        [0] = "ENR",
        [1] = "TERM",
        [2] = "APR",
        [3] = "LPV",
        [4] = "LNAV",
        [5] = "LNAV+V",
        [6] = "L/VNAV",
        [7] = "LP",
        [8] = "L/RNAV",
        [9] = "MAP",
        [10] = "OCS",
        [11] = "LOC",
        [12] = "VOR",
        [13] = "MISS"
    }
    return modes[mode_int] or ""
end

if TEST_MODE then
    function test_anim()
        nav_mode = get_nav_mode_text(2)
        source = "LOC"
        gs_active = true
        gs_label = "GS"
        gs_deflection = 0
        gs_valid = true
        track = 180              -- <<<<<<<<<<< TEST TRACK VALUE (e.g. 30 deg)
        cdi_flag = 1 -- TO
        heading = 0
        hdg_bug = 0
        course = 0
        cdi_deflection = 0
        dis = 14.7
        ete = "06:05"
        redraw()
    end
    timer_start(0, 0.03, test_anim)
else
    
    function radians_to_degrees(radians)
        return radians * (180 / math.pi)
    end
    
    --fs2020_variable_subscribe("L:WTAP_LNav_Obs_Course", "Number", function(c)
    --    print(c)
    --    end
    --    )
    
    --"L:WTAP_LNav_Obs_Course", "Number",
    --"HSI BEARING", "Degrees",

    fs2020_variable_subscribe(
        "GPS DRIVES NAV1", "bool",
        "GPS OBS ACTIVE", "bool",
        "HSI BEARING", "Degrees",
        "PLANE HEADING DEGREES TRUE", "Degrees",
        "AUTOPILOT HEADING LOCK DIR:1", "Degrees",
        "NAV SELECTED SOURCE", "Enum",
        "NAV OBS:1", "Degrees",
        "NAV TOFROM:1", "Number",
        "HSI CDI NEEDLE", "Number",
        "GPS WP DISTANCE", "Meters",
        "GPS WP ETE", "Seconds",
        "GPS APPROACH APPROACH TYPE", "Enum", -- nav mode integer
        "GPS GROUND MAGNETIC TRACK", "Radians",        -- <<<<<<<<<<< TRACK from MSFS2020

        -- GS/GP values
        "NAV HAS GLIDE SLOPE:1", "Number",
        "NAV GS FLAG:1", "Bool",
        "L:WTAP:GP_Vertical_Deviation", "Number",
        "GPS HAS GLIDEPATH", "Bool",

        function(gps, obs, hsi_brg, hdg, hdgBug, navSource, nav_obs, tofrom, deflect, gpsDist, gpsEte, approachType, msfs_track,
                 nav1_gs, nav1_gs_flag, gps_gp_dev, gps_gp_flag)
            nav_gps = gps
            heading = hdg
            hdg_bug = hdgBug
            cdi_deflection = deflect/50
            cdi_flag = tofrom
            dis = gpsDist / 1852.0
            local min = math.floor(gpsEte / 60)
            local sec = math.floor(gpsEte % 60)
            ete = string.format("%02d:%02d", min, sec)
            nav_mode = get_nav_mode_text(approachType)
            track = radians_to_degrees(msfs_track)
            course = nav_obs
            
            if nav_gps then
                if not obs then--not obs mode, normal GPS
                    course = hsi_brg
                end
                source = "GPS"
                course_color = magenta
            elseif navSource == 1 then
                source = "VOR 1"
                course_color = green
            elseif navSource == 2 then
                source = "VOR 2"
                course_color = green
            elseif navSource == 4 then
                source = "LOC"
                course_color = green
            else
                source = "VOR"
                course_color = green
            end

            gs_active = false
            gs_valid = false
            gs_label = ""
            gs_deflection = 0

            if nav_mode == "APR" or nav_mode == "LPV" or nav_mode == "L/VNAV" or nav_mode == "LOC" then
                if nav1_gs_flag == false then
                    gs_active = true
                    gs_label = "GS"
                    gs_deflection = nav1_gs
                    gs_valid = true
                end
            end

            if (nav_mode == "LPV" or nav_mode == "L/VNAV" or nav_mode == "LNAV+V" or nav_mode == "LP") and gps_gp_flag == false then
                gs_active = true
                gs_label = "GP"
                gs_deflection = gps_gp_dev
                gs_valid = true
            end

            redraw()
        end
    )
end

button_hdg = button_add(nil, nil, 86, 232, 38, 33, hdg_pressed)
button_crs = button_add(nil, nil, 198, 232, 38, 33, crs_pressed)
knob_outer = dial_add("rotary_outer.png", 5, 255, 60, 60, dial_out)
knob_inner = dial_add("knob_inner.png", 15, 265, 40, 40, dial_in)
button = button_add(nil, nil, 20, 270, 20, 20, button_pressed)