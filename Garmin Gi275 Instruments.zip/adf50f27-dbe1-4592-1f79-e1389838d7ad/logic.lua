-- GI-275 HSI Lua file for Air Manager (MSFS2020, Canvas API)
-- ...[previous comments omitted for brevity]...

local W, H = 320, 320

local TEST_MODE = false--true

local white = "white"
local cyan = "#00eaff"
local magenta = "#e049b0"
local green = "#00ff00"
local grey = "#555555"

local hdg_selected = false
local crs_selected = false

local heading = 0
local hdg_bug = 0
local course = 0
local track = 0        -- <<<<<<<<<<< NEW: Aircraft track, for magenta triangle
local source = "VOR 1"
local course_color = green
local cdi_deflection = 0
local cdi_flag = 1 -- 1=TO, 2=FROM
local nav_gps = true
local mag_var = 11

local dis = 0.0      -- Distance to waypoint (nautical miles)
local ete = "00:00"  -- Estimated time enroute (MM:SS)
local nav_mode = ""  -- Navigation mode ("ENR", "LPV", etc.)

-- GS/GP logic
local gs_active = false
local gs_label = ""
local gs_deflection = 0      -- -2 to +2, 0=center, negative=below, positive=above
local gs_valid = false
local gp_active = false
local gp_valid = false
local ap_gs_active = false -- autopilot has captured gs/gp

--VNAV deviation
local vnav_dev = 0
local vnav_valid = false

-- Single variable to control all vertical deviation X position
local GS_CDI_X = 250
local GS_CDI_Y = 80
local GS_CDI_W = 23
local GS_CDI_H = 150

local compass_img = img_add("compass card.png", 15, 10, 288, 287)
local layer2_img = img_add("Gi-275 HSI layer 2.png", 0, 0, 320, 320)
local heading_bug_img = img_add("Gi-275 bug.png", 0, 0, 25, 20)
local vert_cdi_img = img_add("CDI.png", GS_CDI_X, GS_CDI_Y, GS_CDI_W, GS_CDI_H)
visible(vert_cdi_img, false)

function heading_to_text(val)
    val = math.floor(val + 0.5) % 360
    return string.format("%03d", val)
end

function draw_track_triangle(cx, cy, radius, heading, track)
    -- Draw a small magenta triangle indicating track above compass card
    -- Place over the compass row, above the card
    local rel_track = (track - heading + 360) % 360
    local track_angle = math.rad(rel_track - 90)
    local tri_radius = radius + 20
    local tri_len = 18    -- length of triangle
    local tri_wid = 12    -- width of triangle at base

    -- Triangle tip (pointing at track)
    local tip_x = cx + tri_radius * math.cos(track_angle)
    local tip_y = cy + tri_radius * math.sin(track_angle)

    -- Triangle base corners (perpendicular to track direction)
    local perp_ang = track_angle + math.pi / 2
    local base_x = cx + (tri_radius - tri_len) * math.cos(track_angle)
    local base_y = cy + (tri_radius - tri_len) * math.sin(track_angle)
    local base1_x = base_x - tri_wid/2 * math.cos(perp_ang)
    local base1_y = base_y - tri_wid/2 * math.sin(perp_ang)
    local base2_x = base_x + tri_wid/2 * math.cos(perp_ang)
    local base2_y = base_y + tri_wid/2 * math.sin(perp_ang)
    _triangle(tip_x, tip_y, base1_x, base1_y, base2_x, base2_y)
    _fill(magenta)
end

function draw_vertical_cdi()
    visible(vert_cdi_img, false)
    if not gs_active or not gs_valid then return end

    visible(vert_cdi_img, true)

    local img_top = 80
    local cdi_bar_x = 260
    local cdi_center = 165
    local dot_radius = 7
    local dot_spacing = 12
    local max_dots = 5
    local deg_per_dot = 0.5 -- GS standard

    -- --- GS/GP indicator ---
    local deviation_in_dots = gs_deflection / deg_per_dot
    deviation_in_dots = math.max(-max_dots, math.min(max_dots, deviation_in_dots))
    local diamond_y = cdi_center - (dot_spacing * deviation_in_dots)
    local diamond_x = cdi_bar_x+1
    local diamond_size = dot_radius

    local src_text = "G"
    local src_color = "green"
    if gs_label == "GP" then
        src_color = "magenta"
        src_text = "G"
    elseif gs_label == "VNAV" then
        src_color = "magenta"
        src_text = "V"
    end

    local box_w = 24
    local box_h = 20
    local box_x = cdi_bar_x - box_w/2
    local box_y = img_top + 11

    -- Draw GS/GP source letter inside box, centered
    _txt(
        src_text,
        "size:16; font:arimo_bold.ttf; color:" .. src_color .. "; halign:center; valign:center",
        box_x+15, box_y, box_w, box_h
    )

    -- Draw filled diamond for GS/GP
    _move_to(diamond_x, diamond_y - diamond_size)
    _line_to(diamond_x + diamond_size, diamond_y)
    _line_to(diamond_x, diamond_y + diamond_size)
    _line_to(diamond_x - diamond_size, diamond_y)
    _line_to(diamond_x, diamond_y - diamond_size)
    if ap_gs_active then
        _fill(src_color)
    end
    _stroke(src_color, 2)

    -- --- VNAV indicator (can be shown at same time) ---
    if vnav_valid then
        local vnav_deviation_in_dots = vnav_dev / deg_per_dot
        vnav_deviation_in_dots = math.max(-max_dots, math.min(max_dots, vnav_deviation_in_dots))
        local v_y = cdi_center - (dot_spacing * vnav_deviation_in_dots)
        local v_x = cdi_bar_x+1

        local v_box_x = cdi_bar_x - box_w/2
        local v_box_y = img_top + 34  -- Slightly below GS/GP box, adjust as needed

        -- VNAV magenta box and "V"
        if not (gs_label == "GS" or gs_label == "GP") then
            _txt(
                "V",
                "size:16; font:arimo_bold.ttf; color:magenta; halign:center; valign:center",
                v_box_x+15, v_box_y-22, box_w, box_h
            )
        end
        

        -- Draw left-facing magenta V
        local v_size = dot_radius * 1.5
        local shift_x = -7
        _move_to(v_x + shift_x, v_y)
        _line_to(v_x + shift_x + v_size, v_y - v_size/2)
        _move_to(v_x + shift_x, v_y)
        _line_to(v_x + shift_x + v_size, v_y + v_size/2)
        _stroke("magenta", 2)
    end
end

function clamp(val, min, max)
    if val < min then return min end
    if val > max then return max end
    return val
end

function draw_hsi()
    local cx, cy = W/2, H/2
    local radius = 125

    -- Shift CDI center up by 10 pixels
    local cdi_cx, cdi_cy = cx, cy - 5

    -- CDI-specific vertical adjustment (move up by 5 pixels)
    local cdi_cy_adj = cdi_cy - 2
    local cy_cdi_center = cdi_cy_adj

    -- Compass card
    local img_rotation = -(heading)
    img_move(compass_img, 15, 10, 288, 287)
    img_rotate(compass_img, img_rotation)

    -- TRACK TRIANGLE (magenta, above compass row)
    draw_track_triangle(cx, cy, radius, heading, track)

    -- CDI needle logic
    local rel_course = (course - heading + 360) % 360
    local course_rad = math.rad(rel_course - 90)
    local cdi_angle = course_rad
    local cdi_max_deflect = 2
    local cdi_dot_spacing = 22
    local cdi_length_top = 80
    local cdi_length_bottom = -55

    local cx_cdi_center = cdi_cx
    -- Use cy_cdi_center (already adjusted up by 5 pixels for CDI)
    local cdi_top_x = cx_cdi_center + cdi_length_top * math.cos(cdi_angle)
    local cdi_top_y = cy_cdi_center + cdi_length_top * math.sin(cdi_angle)
    local cdi_bottom_x = cx_cdi_center - cdi_length_bottom * math.cos(cdi_angle)
    local cdi_bottom_y = cy_cdi_center - cdi_length_bottom * math.sin(cdi_angle)

    -- CDI dots (centered vertically, use adjusted cy)
    for dot = -cdi_max_deflect, cdi_max_deflect do
        local dx = cdi_cx + cdi_dot_spacing * dot * math.cos(cdi_angle + math.pi/2)
        local dy = cdi_cy_adj + cdi_dot_spacing * dot * math.sin(cdi_angle + math.pi/2)
        _circle(dx, dy, 6)
        _fill(white)
        _stroke("black", 2)
    end

    -- Main CDI needle (centered, use adjusted cy)
    _move_to(cdi_bottom_x, cdi_bottom_y)
    _line_to(cdi_top_x, cdi_top_y)
    _stroke(course_color, 6)

    -- Mirrored needle (use adjusted cy)
    local secondary_offset = cdi_length_top + math.abs(cdi_length_bottom)
    local sec_cx = cx_cdi_center - secondary_offset * math.cos(cdi_angle)
    local sec_cy = cy_cdi_center - secondary_offset * math.sin(cdi_angle)
    local sec_top_x = sec_cx + cdi_length_top * math.cos(cdi_angle)
    local sec_top_y = sec_cy + cdi_length_top * math.sin(cdi_angle)
    local sec_bottom_x = sec_cx - cdi_length_bottom * math.cos(cdi_angle)
    local sec_bottom_y = sec_cy - cdi_length_bottom * math.sin(cdi_angle)
    _move_to(sec_bottom_x, sec_bottom_y)
    _line_to(sec_top_x, sec_top_y)
    _stroke(course_color, 6)

    -- Deviation bar (confined CDI deflection, use adjusted cy)
    local deviation_dot = clamp(cdi_deflection, -cdi_max_deflect, cdi_max_deflect)
    local bar_len = 80
    local bar_wid = 5
    local bar_cx = cdi_cx + cdi_dot_spacing * deviation_dot * math.cos(cdi_angle + math.pi/2)
    local bar_cy = cdi_cy_adj + cdi_dot_spacing * deviation_dot * math.sin(cdi_angle + math.pi/2)
    local bar_x1 = bar_cx - bar_len/2 * math.cos(cdi_angle)
    local bar_y1 = bar_cy - bar_len/2 * math.sin(cdi_angle)
    local bar_x2 = bar_cx + bar_len/2 * math.cos(cdi_angle)
    local bar_y2 = bar_cy + bar_len/2 * math.sin(cdi_angle)
    _move_to(bar_x1, bar_y1)
    _line_to(bar_x2, bar_y2)
    _stroke(course_color, bar_wid)

    draw_top_triangle(cx_cdi_center, cy_cdi_center, cdi_angle, cdi_length_top, course_color)

    -- TO/FROM triangle (use adjusted cy)
    local tri_len = 16
    local tri_wid = 12
    local tri_angle = cdi_angle
    local tri_offset = 36
    local base_x, base_y, tip_x, tip_y

    if cdi_flag == 1 then
        base_x = cx_cdi_center + tri_offset * math.cos(tri_angle)
        base_y = cy_cdi_center + tri_offset * math.sin(tri_angle)
        tip_x = base_x + tri_len * math.cos(tri_angle)
        tip_y = base_y + tri_len * math.sin(tri_angle)
    else
        base_x = cx_cdi_center - tri_offset * math.cos(tri_angle)
        base_y = cy_cdi_center - tri_offset * math.sin(cdi_angle)
        tip_x = base_x - tri_len * math.cos(tri_angle)
        tip_y = base_y - tri_len * math.sin(tri_angle)
    end

    local perp_ang = tri_angle + math.pi / 2
    local base1_x = base_x - tri_wid/2 * math.cos(perp_ang)
    local base1_y = base_y - tri_wid/2 * math.sin(perp_ang)
    local base2_x = base_x + tri_wid/2 * math.cos(perp_ang)
    local base2_y = base_y + tri_wid/2 * math.sin(perp_ang)
    _triangle(tip_x, tip_y, base1_x, base1_y, base2_x, base2_y)
    _fill(course_color)

    -- Distance and ETE readout (bottom left)
    _txt("DIS:", "size:15; font:arimo_bold.ttf; color:white; align:right", 90, 190, 60, 22)
    _txt(string.format("%.1f", dis), "size:15; font:arimo_bold.ttf; color:"..magenta.."; align:left", 120, 190, 60, 22)
    _txt("ETE:", "size:15; font:arimo_bold.ttf; color:white; align:right", 170, 190, 60, 22)
    _txt(ete, "size:16; font:arimo_bold.ttf; color:"..magenta.."; align:left", 200, 190, 60, 22)

    _txt(source, "size:18; font:arimo_bold.ttf; color:"..course_color.."; align:center", cx-70, 100, 96, 28)
    _txt(nav_mode, "size:18; font:arimo_bold.ttf; color:"..course_color.."; align:left", cx+35, 100, 60, 28)

    img_move(layer2_img, 0, 0, 320, 320)

    -- HDG bug
    local rel_hdg_bug = (hdg_bug - heading + 360) % 360
    local hdg_angle = math.rad(rel_hdg_bug - 90)
    local bug_radius = radius + 10
    local bug_x = cx + bug_radius * math.cos(hdg_angle) - 12.5
    local bug_y = cy + bug_radius * math.sin(hdg_angle) - 15
    img_move(heading_bug_img, bug_x, bug_y, 25, 20)
    img_rotate(heading_bug_img, rel_hdg_bug)

    -- HDG/CRS text boxes
    local hdg_box_x, hdg_box_y, hdg_box_w, hdg_box_h = 86, 232, 38, 33
    if hdg_selected then
        _rect(hdg_box_x-3, hdg_box_y-3, hdg_box_w+6, hdg_box_h+6, 7)
        _stroke(cyan, 4)
    end
    _txt(heading_to_text(hdg_bug).."°", "size:20; font:arimo_bold.ttf; color:"..cyan.."; align:center", hdg_box_x, hdg_box_y+14, hdg_box_w, 18)

    local crs_box_x, crs_box_y, crs_box_w, crs_box_h = 198, 232, 38, 33
    if crs_selected then
        _rect(crs_box_x-3, crs_box_y-3, crs_box_w+6, crs_box_h+6, 7)
        _stroke(green, 4)
    end
    _txt(heading_to_text(course).."°", "size:20; font:arimo_bold.ttf; color:"..course_color.."; align:center", crs_box_x, crs_box_y+14, crs_box_w, 18)

    -- Current heading text
    local heading_num = heading_to_text(heading)
    local heading_str = heading_num
    _txt(heading_str.."°", "size:26; font:arimo_bold.ttf; color:white; align:center", cx-20, 50, 72, 36)

    img_add("Gi-275 bezel.png", 0, 0, 320, 320)

    draw_vertical_cdi()
end

function draw_top_triangle(cx_cdi_center, cy_cdi_center, cdi_angle, cdi_length_top, color)
    local tri_len = 18
    local tri_wid = 14
    local top_x = cx_cdi_center + cdi_length_top * math.cos(cdi_angle)
    local top_y = cy_cdi_center + cdi_length_top * math.sin(cdi_angle)
    local tip_x = top_x + tri_len * math.cos(cdi_angle)
    local tip_y = top_y + tri_len * math.sin(cdi_angle)
    local perp_ang = cdi_angle + math.pi / 2
    local base1_x = top_x - tri_wid/2 * math.cos(perp_ang)
    local base1_y = top_y - tri_wid/2 * math.sin(perp_ang)
    local base2_x = top_x + tri_wid/2 * math.cos(perp_ang)
    local base2_y = top_y + tri_wid/2 * math.sin(perp_ang)
    _triangle(tip_x, tip_y, base1_x, base1_y, base2_x, base2_y)
    _fill(color)
end

canvas_id = canvas_add(0, 0, W, H, function() draw_hsi() end)

function redraw()
    canvas_draw(canvas_id, function() draw_hsi() end)
end

function hdg_pressed()
    hdg_selected = true
    crs_selected = false
    redraw()
end

function crs_pressed()
    crs_selected = true
    hdg_selected = false
    redraw()
end

function dial_in(direction)
    if hdg_selected then
        if direction == 1 then
            fs2020_event("HEADING_BUG_INC")
        else
            fs2020_event("HEADING_BUG_DEC")
        end
        --if direction == 1 then hdg_bug = (hdg_bug + 1) % 360
        --elseif direction == -1 then hdg_bug = (hdg_bug - 1 + 360) % 360 end
    elseif crs_selected then
        if direction == 1 then
            fs2020_event("VOR1_OBI_INC")
        else
            fs2020_event("VOR1_OBI_DEC")
        end
        --if direction == 1 then course = (course + 1) % 360
        --elseif direction == -1 then course = (course - 1 + 360) % 360 end
    end
    redraw()
end

function dial_out(direction)
    -- For future expansion
end

function button_pressed()
    print("button")
end

-- Utility: map MSFS nav mode integer to text
function get_nav_mode_text(mode_int)
    local modes = {
        [0] = "ENR",
        [1] = "TERM",
        [2] = "APR",
        [3] = "LPV",
        [4] = "LNAV",
        [5] = "LNAV+V",
        [6] = "L/VNAV",
        [7] = "LP",
        [8] = "L/RNAV",
        [9] = "MAP",
        [10] = "OCS",
        [11] = "LOC",
        [12] = "VOR",
        [13] = "MISS"
    }
    return modes[mode_int] or ""
end

function get_apr_type_text(mode_int)
    local modes = {
        [1] = "GPS",
        [2] = "VOR",
        [3] = "NDB",
        [4] = "ILS",
        [5] = "Localizer",
        [6] = "SDF",
        [7] = "LDA",
        [8] = "VOR/ DME",
        [9] = "NDB/ DME",
        [10] = "RNAV",
        [11] = "Backcourse"
    }
    return modes[mode_int] or ""
end

function get_nav_type_text(int)
    local modes = {
        [35] = "VOR",
        [193] = "ILS",
    }
    return modes[int] or ""
end

if TEST_MODE then
    function test_anim()
        nav_mode = get_nav_mode_text(2)
        source = "LOC"
        gs_active = true
        gs_label = "GS"
        gs_deflection = 0
        gs_valid = true
        track = 180              -- <<<<<<<<<<< TEST TRACK VALUE (e.g. 30 deg)
        cdi_flag = 1 -- TO
        heading = 0
        hdg_bug = 0
        course = 0
        cdi_deflection = 0
        dis = 14.7
        ete = "06:05"
        redraw()
    end
    timer_start(0, 0.03, test_anim)
else
    
    function radians_to_degrees(radians)
        return radians * (180 / math.pi)
    end
    
    --fs2020_variable_subscribe("L:WTAP_LNav_Obs_Course", "Number", function(c)
    --    print(c)
    --    end
    --    )
    
    --"L:WTAP_LNav_Obs_Course", "Number",
    --"HSI BEARING", "Degrees",

    -- Vertical CDI (Glideslope/Glidepath) subscription and logic for Air Manager & MSFS2020

fs2020_variable_subscribe(
    -- Navigation sources
    "GPS DRIVES NAV1", "bool",                        -- gps true if GPS is the nav source
    "GPS OBS ACTIVE", "bool",                         -- obs true if GPS OBS mode is active
    "HSI BEARING", "Degrees",                         -- hsi_brg HSI bearing
    "PLANE HEADING DEGREES MAGNETIC", "Degrees",      -- hdg Aircraft heading
    "AUTOPILOT HEADING LOCK DIR:1", "Degrees",        -- hdgBug AP heading bug
    "NAV OBS:1", "Degrees",                           -- nav_obs NAV1 OBS/course
    "NAV TOFROM:1", "Number",                         -- tofrom NAV1 TO/FROM flag
    "HSI CDI NEEDLE", "Number",                       -- deflect HSI CDI deflection
    "GPS WP DISTANCE", "Meters",                      -- gpsDist Distance to GPS waypoint
    "GPS WP ETE", "Seconds",                          -- gpsEte Estimated time enroute to waypoint
    "GPS APPROACH APPROACH TYPE", "Enum",             -- approachType GPS approach type
    "GPS GROUND MAGNETIC TRACK", "Radians",           -- msfs_track Magnetic track from GPS

    -- Vertical guidance
    "NAV HAS GLIDE SLOPE:1", "Bool",                  -- nav1_gs NAV1 has glideslope
    "NAV GS FLAG:1", "Bool",                          -- nav1_gs_flag GS valid flag
    "GPS HAS GLIDEPATH", "Bool",                      -- gps_gp GPS has glidepath
    "HSI HAS LOCALIZER", "Bool",                      -- nav1_loc HSI has localizer
    "NAV CODES:1", "Flags",                           -- nav1_flags NAV1 flags
    "GPS APPROACH MODE", "Enum",                      -- nav1_mode GPS approach mode
    "NAV GLIDE SLOPE ERROR:1", "Degrees",             -- gs_dev ILS glideslope deviation
    "MAGVAR", "Degrees",                              -- magVar Magnetic variation
    "GPS VERTICAL ANGLE ERROR", "Degrees",            -- gps_gp_dev GPS glidepath deviation
    "L:WTAP_VNav_Vertical_Deviation", "Number",    -- vnav_deviation
    "AUTOPILOT GLIDESLOPE ACTIVE", "Bool",            --ap_gs

    function(
        gps, obs, hsi_brg, hdg, hdgBug, nav_obs, tofrom, deflect, gpsDist, gpsEte, approachType, msfs_track,
        nav1_gs, nav1_gs_flag, gps_gp, nav1_loc, nav1_flags, nav1_mode, gs_dev, magvar, gps_gp_dev, vnav_deviation, ap_gs
    )
        -- NAV source logic
        nav_gps = gps
        heading = hdg
        hdg_bug = hdgBug
        cdi_deflection = deflect/50
        cdi_flag = tofrom
        dis = gpsDist / 1852.0 -- meters to nautical miles
        local min = math.floor(gpsEte / 60)
        local sec = math.floor(gpsEte % 60)
        ete = string.format("%02d:%02d", min, sec)
        gps_apr_type = get_apr_type_text(approachType)
        track = radians_to_degrees(msfs_track)
        course = nav_obs
        nav1_type = get_nav_type_text(nav1_flags)
        nav_mode = get_nav_mode_text(nav1_mode)
        ap_gs_active = ap_gs
        
        --VNAV
        vnav_dev = vnav_deviation
        vnav_valid = false
        if vnav_dev < 1000 and vnav_dev > -1000 and ap_gs_active == false then
            vnav_valid = true
            vnav_dev = vnav_dev / 400
        end

        -- Use HSI bearing for GPS course unless in OBS mode
        if nav_gps then
            cdi_flag = 1
            if not obs then
                course = hsi_brg
            end
            source = "GPS"
            course_color = magenta
        elseif nav1_loc and nav1_gs then
            source = "ILS"
            course_color = green
        elseif nav1_loc then  
            source = "LOC"
            course_color = green
        else
            source = nav1_type
            course_color = green
        end

        -- Glideslope / Glidepath logic
        gs_active = false
        gs_valid = false
        gs_label = ""
        gs_deflection = 0
        deg_per_dot = 0.5 -- default (ILS)

        -- GPS Glidepath
        if gps_gp and gps then
            gs_active = true
            gs_label = "GP"
            gs_deflection = -gps_gp_dev*3.3
            deg_per_dot = 0.3 -- WAAS-like scaling for GPS GP
            gs_valid = true   
        -- ILS Glideslope
        elseif nav1_gs and not gps then
            if nav1_gs_flag == true then
                gs_active = true
                gs_label = "GS"
                gs_deflection = -gs_dev
                deg_per_dot = 0.5 -- Standard ILS scaling
                gs_valid = true
            end
        else
            gs_active = false
            gs_label = ""
            gs_deflection = 0
            gs_valid = false
        end

        -- Sign correction (if needed: uncomment if needle reversed)
        -- gs_deflection = -gs_deflection

        -- Call your drawing routine
        redraw()
    end
)
end

button_hdg = button_add(nil, nil, 86, 232, 38, 33, hdg_pressed)
button_crs = button_add(nil, nil, 198, 232, 38, 33, crs_pressed)
knob_outer = dial_add("rotary_outer.png", 5, 255, 60, 60, dial_out)
knob_inner = dial_add("knob_inner.png", 15, 265, 40, 40, dial_in)
button = button_add(nil, nil, 20, 270, 20, 20, button_pressed)