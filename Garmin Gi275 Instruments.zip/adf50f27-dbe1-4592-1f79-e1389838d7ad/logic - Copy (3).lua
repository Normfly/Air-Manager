-- GI-275 HSI Lua file for Air Manager (MSFS2020, Canvas API)
-- TO/FROM triangle always points to the station, flips side with TO/FROM flag.
-- Triangle rotates with course, is above (TO) or below (FROM) the CDI center.

local W, H = 320, 320

local white = "white"
local cyan = "#00eaff"
local magenta = "#e049b0"
local green = "#00ff00"

local hdg_selected = false
local crs_selected = false

local heading = 0
local hdg_bug = 0
local course = 0
local source = "VOR 1"
local course_color = green
local cdi_deflection = 0
local cdi_flag = 1 -- 1=TO, 2=FROM

local compass_img = img_add("compass card.png", 15, 10, 288, 287)
local layer2_img = img_add("Gi-275 HSI layer 2.png", 0, 0, 320, 320)
local heading_bug_img = img_add("Gi-275 bug.png", 0, 0, 25, 20)

function heading_to_text(val)
    val = math.floor(val + 0.5) % 360
    return string.format("%03d", val)
end

function draw_hsi()
    local cx, cy = W/2, H/2
    local radius = 125

    -- Shift CDI center up by 10 pixels
    local cdi_cx, cdi_cy = cx, cy - 10

    -- Compass card
    local img_rotation = -(heading)
    img_move(compass_img, 15, 10, 288, 287)
    img_rotate(compass_img, img_rotation)

    -- CDI needle
    local rel_course = (course - heading + 360) % 360
    local course_rad = math.rad(rel_course - 90)
    local cdi_angle = course_rad
    local cdi_max_deflect = 2
    local cdi_dot_spacing = 22
    local cdi_length_top = 80
    local cdi_length_bottom = -55
    local cx_cdi = cdi_cx + cdi_dot_spacing * cdi_deflection * math.cos(cdi_angle + math.pi/2)
    local cy_cdi = cdi_cy + cdi_dot_spacing * cdi_deflection * math.sin(cdi_angle + math.pi/2) + 24

    local cdi_top_x = cx_cdi + cdi_length_top * math.cos(cdi_angle)
    local cdi_top_y = cy_cdi + cdi_length_top * math.sin(cdi_angle)
    local cdi_bottom_x = cx_cdi - cdi_length_bottom * math.cos(cdi_angle)
    local cdi_bottom_y = cy_cdi - cdi_length_bottom * math.sin(cdi_angle)

    -- Main CDI needle (unchanged)
    _move_to(cdi_bottom_x, cdi_bottom_y)
    _line_to(cdi_top_x, cdi_top_y)
    _stroke(green, 6)

    -- SECONDARY NEEDLE, mirrored on the other side of the dots
    -- Offset by the same "length" as the original, but in the opposite direction.
    local secondary_offset = cdi_length_top + math.abs(cdi_length_bottom)
    local sec_cx = cx_cdi - secondary_offset * math.cos(cdi_angle)
    local sec_cy = cy_cdi - secondary_offset * math.sin(cdi_angle)
    local sec_top_x = sec_cx + cdi_length_top * math.cos(cdi_angle)
    local sec_top_y = sec_cy + cdi_length_top * math.sin(cdi_angle)
    local sec_bottom_x = sec_cx - cdi_length_bottom * math.cos(cdi_angle)
    local sec_bottom_y = sec_cy - cdi_length_bottom * math.sin(cdi_angle)
    _move_to(sec_bottom_x, sec_bottom_y)
    _line_to(sec_top_x, sec_top_y)
    _stroke(green, 6)

    -- TO/FROM triangle always points to station, flips side
    local tri_len = 16
    local tri_wid = 12
    local tri_angle = cdi_angle
    local tri_offset = 36
    local base_x, base_y, tip_x, tip_y

    if cdi_flag == 1 then
        -- TO: triangle is above center, points in OBS/course direction
        base_x = cx_cdi + tri_offset * math.cos(tri_angle)
        base_y = cy_cdi + tri_offset * math.sin(tri_angle)
        tip_x = base_x + tri_len * math.cos(tri_angle)
        tip_y = base_y + tri_len * math.sin(tri_angle)
    else
        -- FROM: triangle is below center, points opposite OBS/course direction
        base_x = cx_cdi - tri_offset * math.cos(tri_angle)
        base_y = cy_cdi - tri_offset * math.sin(tri_angle)
        tip_x = base_x - tri_len * math.cos(tri_angle)
        tip_y = base_y - tri_len * math.sin(tri_angle)
    end

    -- Triangle base corners (perpendicular to course direction)
    local perp_ang = tri_angle + math.pi / 2
    local base1_x = base_x - tri_wid/2 * math.cos(perp_ang)
    local base1_y = base_y - tri_wid/2 * math.sin(perp_ang)
    local base2_x = base_x + tri_wid/2 * math.cos(perp_ang)
    local base2_y = base_y + tri_wid/2 * math.sin(perp_ang)
    _triangle(tip_x, tip_y, base1_x, base1_y, base2_x, base2_y)
    _fill(green)

    -- CDI dots
    for dot = -cdi_max_deflect, cdi_max_deflect do
        local dx = cdi_cx + cdi_dot_spacing * dot * math.cos(cdi_angle + math.pi/2)
        local dy = cdi_cy + cdi_dot_spacing * dot * math.sin(cdi_angle + math.pi/2) + 24
        _circle(dx, dy, 6)
        _fill(white)
        _stroke("black", 2)
    end

    -- Layer2 overlay
    img_move(layer2_img, 0, 0, 320, 320)

    -- HDG bug (position restored to original, using cx, cy)
    local rel_hdg_bug = (hdg_bug - heading + 360) % 360
    local hdg_angle = math.rad(rel_hdg_bug - 90)
    local bug_radius = radius + 10
    local bug_x = cx + bug_radius * math.cos(hdg_angle) - 12.5
    local bug_y = cy + bug_radius * math.sin(hdg_angle) - 15
    img_move(heading_bug_img, bug_x, bug_y, 25, 20)
    img_rotate(heading_bug_img, rel_hdg_bug)

    -- HDG/CRS text boxes
    local hdg_box_x, hdg_box_y, hdg_box_w, hdg_box_h = 86, 232, 38, 33
    if hdg_selected then
        _rect(hdg_box_x-3, hdg_box_y-3, hdg_box_w+6, hdg_box_h+6, 7)
        _stroke(cyan, 4)
    end
    _txt(heading_to_text(hdg_bug).."°", "size:20; font:arimo_bold.ttf; color:"..cyan.."; align:center", hdg_box_x, hdg_box_y+14, hdg_box_w, 18)

    local crs_box_x, crs_box_y, crs_box_w, crs_box_h = 198, 232, 38, 33
    if crs_selected then
        _rect(crs_box_x-3, crs_box_y-3, crs_box_w+6, crs_box_h+6, 7)
        _stroke(green, 4)
    end
    _txt(heading_to_text(course).."°", "size:20; font:arimo_bold.ttf; color:"..green.."; align:center", crs_box_x, crs_box_y+14, crs_box_w, 18)

    -- Current heading text (down and right)
    local heading_num = heading_to_text(heading)
    local heading_str = heading_num
    _txt(heading_str.."°", "size:26; font:arimo_bold.ttf; color:white; align:center", cx-20, 50, 72, 36)

    -- Source text (green, above CDI)
    _txt(source, "size:18; font:arimo_bold.ttf; color:"..green.."; align:center", cx-48, 100, 96, 28)

    -- Bezel (topmost)
    img_add("Gi-275 bezel.png", 0, 0, 320, 320)
end

canvas_id = canvas_add(0, 0, W, H, function() draw_hsi() end)

function redraw()
    canvas_draw(canvas_id, function() draw_hsi() end)
end

function hdg_pressed()
    hdg_selected = true
    crs_selected = false
    redraw()
end

function crs_pressed()
    crs_selected = true
    hdg_selected = false
    redraw()
end

function dial_in(direction)
    if hdg_selected then
        if direction == 1 then hdg_bug = (hdg_bug + 1) % 360
        elseif direction == -1 then hdg_bug = (hdg_bug - 1 + 360) % 360 end
    elseif crs_selected then
        if direction == 1 then course = (course + 1) % 360
        elseif direction == -1 then course = (course - 1 + 360) % 360 end
    end
    redraw()
end

function dial_out(direction)
    -- For future expansion
end

function button_pressed()
    print("button")
end

if TEST_MODE then
    function test_anim()
        heading = (heading + 0.7) % 360
        hdg_bug = (hdg_bug + 0.5) % 360
        course = (course + 0.3) % 360
        cdi_deflection = 2--math.sin(heading * math.pi / 180) * 2
        -- Simulate TO/FROM flag switch
        if math.sin(heading * math.pi / 180) > 0 then
            cdi_flag = 1 -- TO
        else
            cdi_flag = 2 -- FROM
        end
        redraw()
    end
    timer_start(0, 0.03, test_anim)
else
    fs2020_variable_subscribe(
        "PLANE HEADING DEGREES TRUE", "Degrees",
        "AUTOPILOT HEADING BUG", "Degrees",
        "NAV1 OBS", "Degrees",
        "GPS WP NEXT WP BEARING", "Degrees",
        "NAV SELECTED SOURCE", "Enum",
        "NAV1 CDI", "Number",
        "NAV1 TO/FROM", "Enum",
        function(hdg, hdgBug, navObs, gpsCourse, navSource, cdi, tofrom)
            heading = hdg
            hdg_bug = hdgBug
            cdi_deflection = cdi
            cdi_flag = tofrom -- 1=TO, 2=FROM
            if navSource == 3 then
                course = gpsCourse
                source = "GPS"
                course_color = magenta
            elseif navSource == 1 then
                course = navObs
                source = "VOR 1"
                course_color = green
            elseif navSource == 2 then
                course = navObs
                source = "VOR 2"
                course_color = green
            elseif navSource == 4 then
                course = navObs
                source = "LOC"
                course_color = green
            else
                course = navObs
                source = "VOR"
                course_color = green
            end
            redraw()
        end
    )
end

button_hdg = button_add(nil, nil, 86, 232, 38, 33, hdg_pressed)
button_crs = button_add(nil, nil, 198, 232, 38, 33, crs_pressed)
knob_outer = dial_add("rotary_outer.png", 5, 255, 60, 60, dial_out)
knob_inner = dial_add("knob_inner.png", 15, 265, 40, 40, dial_in)
button = button_add(nil, nil, 20, 270, 20, 20, button_pressed)

