-- GI-275 HSI Lua file for Air Manager (MSFS2020, Canvas API)
-- Layer order: compass card, CDI needle, layer2 overlay, HDG/CRS text boxes, bezel (top)
-- Starts with heading bug and course set to 0
-- Reference sample image for layout: ![image1](image1)
-- HDG/CRS boxes are perfect. Current heading is moved down and right.

local W, H = 320, 320

local white = "white"
local cyan = "#00eaff"
local magenta = "#e049b0"
local green = "#00ff00"

-- Selection state for HDG and CRS box
local hdg_selected = false
local crs_selected = false

-- Variables (updated by sim subscription)
local heading = 0
local hdg_bug = 0
local course = 0
local source = "VOR 1"
local course_color = green
local cdi_deflection = 0

-- Persistent image handles
local compass_img = img_add("compass card.png", 15, 10, 288, 287)
local layer2_img = img_add("Gi-275 HSI layer 2.png", 0, 0, 320, 320)
local heading_bug_img = img_add("Gi-275 bug.png", 0, 0, 25, 20)

function heading_to_text(val)
    val = math.floor(val + 0.5) % 360
    return string.format("%03d", val)
end

function draw_hsi()
    local cx, cy = W/2, H/2
    local radius = 125

    -- 1. Compass card (bottom layer)
    local img_rotation = -(heading)
    img_move(compass_img, 15, 10, 288, 287)
    img_rotate(compass_img, img_rotation)

    -- 2. CDI needle (programmatic, rotates with course, shifted down)
    local rel_course = (course - heading + 360) % 360
    local course_angle = math.rad(rel_course - 90)
    local cdi_max_deflect = 2
    local cdi_dot_spacing = 22
    local cdi_length = 70
    local cdi_angle = course_angle
    local cx_cdi = cx + cdi_dot_spacing * cdi_deflection * math.cos(cdi_angle + math.pi/2)
    local cy_cdi = cy + cdi_dot_spacing * cdi_deflection * math.sin(cdi_angle + math.pi/2) + 24
    local cdi_end_x = cx_cdi + cdi_length * math.cos(cdi_angle)
    local cdi_end_y = cy_cdi + cdi_length * math.sin(cdi_angle)
    _move_to(cx_cdi, cy_cdi)
    _line_to(cdi_end_x, cdi_end_y)
    _stroke(green, 6)

    -- CDI dots
    for dot = -cdi_max_deflect, cdi_max_deflect do
        local dx = cx + cdi_dot_spacing * dot * math.cos(cdi_angle + math.pi/2)
        local dy = cy + cdi_dot_spacing * dot * math.sin(cdi_angle + math.pi/2) + 24
        _circle(dx, dy, 6)
        _fill(white)
        _stroke("black", 2)
    end

    -- 3. Layer2 overlay
    img_move(layer2_img, 0, 0, 320, 320)

    -- 4. HDG bug (above layer2)
    local rel_hdg_bug = (hdg_bug - heading + 360) % 360
    local hdg_angle = math.rad(rel_hdg_bug - 90)
    local bug_radius = radius + 10
    local bug_x = cx + bug_radius * math.cos(hdg_angle) - 12.5
    local bug_y = cy + bug_radius * math.sin(hdg_angle) - 15
    img_move(heading_bug_img, bug_x, bug_y, 25, 20)
    img_rotate(heading_bug_img, rel_hdg_bug)

    -- 5. HDG/CRS text boxes (lower positions, untouched)
    local hdg_box_x, hdg_box_y, hdg_box_w, hdg_box_h = 86, 232, 38, 33
    if hdg_selected then
        _rect(hdg_box_x-3, hdg_box_y-3, hdg_box_w+6, hdg_box_h+6, 7)
        _stroke(cyan, 4)
    end
    _txt(heading_to_text(hdg_bug).."°", "size:20; font:arimo_bold.ttf; color:"..cyan.."; align:center", hdg_box_x, hdg_box_y+14, hdg_box_w, 18)

    local crs_box_x, crs_box_y, crs_box_w, crs_box_h = 198, 232, 38, 33
    if crs_selected then
        _rect(crs_box_x-3, crs_box_y-3, crs_box_w+6, crs_box_h+6, 7)
        _stroke(green, 4)
    end
    _txt(heading_to_text(course).."°", "size:20; font:arimo_bold.ttf; color:"..green.."; align:center", crs_box_x, crs_box_y+14, crs_box_w, 18)

    -- CDI label (center bottom, unchanged)
    _txt("CDI", "size:18; font:arimo_bold.ttf; color:cyan; align:center", cx-24, 272, 48, 34)

    -- Current heading text (moved down and right)
    -- Old: _txt(heading_str, "size:26; font:arimo_bold.ttf; color:white; align:center", cx-36, 18, 72, 36)
    -- New: Down (+y) and right (+x). Adjust as needed to match the image.
    local heading_num = heading_to_text(heading)
    local heading_str = heading_num
    _txt(heading_str.."°", "size:26; font:arimo_bold.ttf; color:white; align:center", cx-20, 50, 72, 36)

    -- Source text (green, above CDI)
    _txt(source, "size:18; font:arimo_bold.ttf; color:"..green.."; align:center", cx-48, 100, 96, 28)

    -- 6. Bezel (topmost)
    img_add("Gi-275 bezel.png", 0, 0, 320, 320)
end

canvas_id = canvas_add(0, 0, W, H, function() draw_hsi() end)

function redraw()
    canvas_draw(canvas_id, function() draw_hsi() end)
end

function hdg_pressed()
    hdg_selected = true
    crs_selected = false
    redraw()
end

function crs_pressed()
    crs_selected = true
    hdg_selected = false
    redraw()
end

function dial_in(direction)
    if hdg_selected then
        if direction == 1 then hdg_bug = (hdg_bug + 1) % 360
        elseif direction == -1 then hdg_bug = (hdg_bug - 1 + 360) % 360 end
    elseif crs_selected then
        if direction == 1 then course = (course + 1) % 360
        elseif direction == -1 then course = (course - 1 + 360) % 360 end
    end
    redraw()
end

function dial_out(direction)
    -- For future expansion
end

function button_pressed()
    print("button")
end

-- MSFS2020 subscriptions
if TEST_MODE then
    function test_anim()
        heading = (heading + 0.7) % 360
        hdg_bug = (hdg_bug + 0.5) % 360
        course = (course + 0.3) % 360
        cdi_deflection = math.sin(heading * math.pi / 180) * 2
        redraw()
    end
    timer_start(0, 0.03, test_anim)
else
    fs2020_variable_subscribe(
        "PLANE HEADING DEGREES TRUE", "Degrees",
        "AUTOPILOT HEADING BUG", "Degrees",
        "NAV1 OBS", "Degrees",
        "GPS WP NEXT WP BEARING", "Degrees",
        "NAV SELECTED SOURCE", "Enum",
        "NAV1 CDI", "Number",
        function(hdg, hdgBug, navObs, gpsCourse, navSource, cdi)
            heading = hdg
            hdg_bug = hdgBug
            cdi_deflection = cdi
            if navSource == 3 then
                course = gpsCourse
                source = "GPS"
                course_color = magenta
            elseif navSource == 1 then
                course = navObs
                source = "VOR 1"
                course_color = green
            elseif navSource == 2 then
                course = navObs
                source = "VOR 2"
                course_color = green
            elseif navSource == 4 then
                course = navObs
                source = "LOC"
                course_color = green
            else
                course = navObs
                source = "VOR"
                course_color = green
            end
            redraw()
        end
    )
end

button_hdg = button_add(nil, nil, 86, 232, 38, 33, hdg_pressed)
button_crs = button_add(nil, nil, 198, 232, 38, 33, crs_pressed)
knob_outer = dial_add("rotary_outer.png", 5, 255, 60, 60, dial_out)
knob_inner = dial_add("knob_inner.png", 15, 265, 40, 40, dial_in)
button = button_add(nil, nil, 20, 270, 20, 20, button_pressed)