-- GI-275 HSI Lua file for Air Manager (MSFS2020, Canvas API)
-- TO/FROM triangle always points to the station, flips side with TO/FROM flag.
-- Triangle rotates with course, is above (TO) or below (FROM) the CDI center.

local W, H = 320, 320

local white = "white"
local cyan = "#00eaff"
local magenta = "#e049b0"
local green = "#00ff00"

local hdg_selected = false
local crs_selected = false

local heading = 0
local hdg_bug = 0
local course = 0
local source = "VOR 1"
local course_color = green
local cdi_deflection = 0
local cdi_flag = 1 -- 1=TO, 2=FROM

local dis = 0.0      -- Distance to waypoint (nautical miles)
local ete = "00:00"  -- Estimated time enroute (MM:SS)
local nav_mode = ""  -- Navigation mode ("ENR", "LPV", etc.)

local compass_img = img_add("compass card.png", 15, 10, 288, 287)
local layer2_img = img_add("Gi-275 HSI layer 2.png", 0, 0, 320, 320)
local heading_bug_img = img_add("Gi-275 bug.png", 0, 0, 25, 20)

function heading_to_text(val)
    val = math.floor(val + 0.5) % 360
    return string.format("%03d", val)
end

function draw_hsi()
    local cx, cy = W/2, H/2
    local radius = 125
    local needle_color = green

    -- Shift CDI center up by 10 pixels
    local cdi_cx, cdi_cy = cx, cy - 10

    -- Compass card
    local img_rotation = -(heading)
    img_move(compass_img, 15, 10, 288, 287)
    img_rotate(compass_img, img_rotation)

    -- CDI needle logic
    local rel_course = (course - heading + 360) % 360
    local course_rad = math.rad(rel_course - 90)
    local cdi_angle = course_rad
    local cdi_max_deflect = 2
    local cdi_dot_spacing = 22
    local cdi_length_top = 80
    local cdi_length_bottom = -55

    -- Center needle
    local cx_cdi_center = cdi_cx
    local cy_cdi_center = cdi_cy + 24
    local cdi_top_x = cx_cdi_center + cdi_length_top * math.cos(cdi_angle)
    local cdi_top_y = cy_cdi_center + cdi_length_top * math.sin(cdi_angle)
    local cdi_bottom_x = cx_cdi_center - cdi_length_bottom * math.cos(cdi_angle)
    local cdi_bottom_y = cy_cdi_center - cdi_length_bottom * math.sin(cdi_angle)

    -- Main CDI needle (centered)
    _move_to(cdi_bottom_x, cdi_bottom_y)
    _line_to(cdi_top_x, cdi_top_y)
    _stroke(needle_color, 6)

    -- Mirrored needle (centered, opposite side)
    local secondary_offset = cdi_length_top + math.abs(cdi_length_bottom)
    local sec_cx = cx_cdi_center - secondary_offset * math.cos(cdi_angle)
    local sec_cy = cy_cdi_center - secondary_offset * math.sin(cdi_angle)
    local sec_top_x = sec_cx + cdi_length_top * math.cos(cdi_angle)
    local sec_top_y = sec_cy + cdi_length_top * math.sin(cdi_angle)
    local sec_bottom_x = sec_cx - cdi_length_bottom * math.cos(cdi_angle)
    local sec_bottom_y = sec_cy - cdi_length_bottom * math.sin(cdi_angle)
    _move_to(sec_bottom_x, sec_bottom_y)
    _line_to(sec_top_x, sec_top_y)
    _stroke(needle_color, 6)

    -- Deviation bar: follows cdi_deflection, matches dot positions
    local deviation_dot = cdi_deflection
    local bar_len = 80
    local bar_wid = 5
    local bar_cx = cdi_cx + cdi_dot_spacing * deviation_dot * math.cos(cdi_angle + math.pi/2)
    local bar_cy = cdi_cy + cdi_dot_spacing * deviation_dot * math.sin(cdi_angle + math.pi/2) + 24
    local bar_x1 = bar_cx - bar_len/2 * math.cos(cdi_angle)
    local bar_y1 = bar_cy - bar_len/2 * math.sin(cdi_angle)
    local bar_x2 = bar_cx + bar_len/2 * math.cos(cdi_angle)
    local bar_y2 = bar_cy + bar_len/2 * math.sin(cdi_angle)
    _move_to(bar_x1, bar_y1)
    _line_to(bar_x2, bar_y2)
    _stroke(needle_color, bar_wid)

    -- TO/FROM triangle always points to station, flips side
    local tri_len = 16
    local tri_wid = 12
    local tri_angle = cdi_angle
    local tri_offset = 36
    local base_x, base_y, tip_x, tip_y

    if cdi_flag == 1 then
        -- TO: triangle is above center, points in OBS/course direction
        base_x = cx_cdi_center + tri_offset * math.cos(tri_angle)
        base_y = cy_cdi_center + tri_offset * math.sin(tri_angle)
        tip_x = base_x + tri_len * math.cos(tri_angle)
        tip_y = base_y + tri_len * math.sin(tri_angle)
    else
        -- FROM: triangle is below center, points opposite OBS/course direction
        base_x = cx_cdi_center - tri_offset * math.cos(tri_angle)
        base_y = cy_cdi_center - tri_offset * math.sin(tri_angle)
        tip_x = base_x - tri_len * math.cos(tri_angle)
        tip_y = base_y - tri_len * math.sin(tri_angle)
    end

    -- Triangle base corners (perpendicular to course direction)
    local perp_ang = tri_angle + math.pi / 2
    local base1_x = base_x - tri_wid/2 * math.cos(perp_ang)
    local base1_y = base_y - tri_wid/2 * math.sin(perp_ang)
    local base2_x = base_x + tri_wid/2 * math.cos(perp_ang)
    local base2_y = base_y + tri_wid/2 * math.sin(perp_ang)
    _triangle(tip_x, tip_y, base1_x, base1_y, base2_x, base2_y)
    _fill(green)

    -- CDI dots
    for dot = -cdi_max_deflect, cdi_max_deflect do
        local dx = cdi_cx + cdi_dot_spacing * dot * math.cos(cdi_angle + math.pi/2)
        local dy = cdi_cy + cdi_dot_spacing * dot * math.sin(cdi_angle + math.pi/2) + 24
        _circle(dx, dy, 6)
        _fill(white)
        _stroke("black", 2)
    end

    -- Distance and ETE readout (bottom left)
    _txt("DIS:", "size:15; font:arimo_bold.ttf; color:white; align:right", 90, 190, 60, 22)
    _txt(string.format("%.1f", dis), "size:15; font:arimo_bold.ttf; color:"..magenta.."; align:left", 120, 190, 60, 22)
    _txt("ETE:", "size:15; font:arimo_bold.ttf; color:white; align:right", 170, 190, 60, 22)
    _txt(ete, "size:16; font:arimo_bold.ttf; color:"..magenta.."; align:left", 200, 190, 60, 22)

        -- Distance and ETE readout (bottom left)
    _txt("DIS:", "size:15; font:arimo_bold.ttf; color:white; align:right", 90, 190, 60, 22)
    _txt(string.format("%.1f", dis), "size:15; font:arimo_bold.ttf; color:"..magenta.."; align:left", 120, 190, 60, 22)
    _txt("ETE:", "size:15; font:arimo_bold.ttf; color:white; align:right", 170, 190, 60, 22)
    _txt(ete, "size:16; font:arimo_bold.ttf; color:"..magenta.."; align:left", 200, 190, 60, 22)

    -- Source text (original location!)
    _txt(source, "size:18; font:arimo_bold.ttf; color:"..course_color.."; align:center", cx-70, 100, 96, 28)
    -- Nav mode/phase (to right)
    _txt("ENR", "size:18; font:arimo_bold.ttf; color:green; align:left", cx+15, 100, 60, 28)

    -- Layer2 overlay
    img_move(layer2_img, 0, 0, 320, 320)

    -- HDG bug
    local rel_hdg_bug = (hdg_bug - heading + 360) % 360
    local hdg_angle = math.rad(rel_hdg_bug - 90)
    local bug_radius = radius + 10
    local bug_x = cx + bug_radius * math.cos(hdg_angle) - 12.5
    local bug_y = cy + bug_radius * math.sin(hdg_angle) - 15
    img_move(heading_bug_img, bug_x, bug_y, 25, 20)
    img_rotate(heading_bug_img, rel_hdg_bug)

    -- HDG/CRS text boxes
    local hdg_box_x, hdg_box_y, hdg_box_w, hdg_box_h = 86, 232, 38, 33
    if hdg_selected then
        _rect(hdg_box_x-3, hdg_box_y-3, hdg_box_w+6, hdg_box_h+6, 7)
        _stroke(cyan, 4)
    end
    _txt(heading_to_text(hdg_bug).."°", "size:20; font:arimo_bold.ttf; color:"..cyan.."; align:center", hdg_box_x, hdg_box_y+14, hdg_box_w, 18)

    local crs_box_x, crs_box_y, crs_box_w, crs_box_h = 198, 232, 38, 33
    if crs_selected then
        _rect(crs_box_x-3, crs_box_y-3, crs_box_w+6, crs_box_h+6, 7)
        _stroke(green, 4)
    end
    _txt(heading_to_text(course).."°", "size:20; font:arimo_bold.ttf; color:"..green.."; align:center", crs_box_x, crs_box_y+14, crs_box_w, 18)

    -- Current heading text
    local heading_num = heading_to_text(heading)
    local heading_str = heading_num
    _txt(heading_str.."°", "size:26; font:arimo_bold.ttf; color:white; align:center", cx-20, 50, 72, 36)

    -- Bezel
    img_add("Gi-275 bezel.png", 0, 0, 320, 320)
end

canvas_id = canvas_add(0, 0, W, H, function() draw_hsi() end)

function redraw()
    canvas_draw(canvas_id, function() draw_hsi() end)
end

function hdg_pressed()
    hdg_selected = true
    crs_selected = false
    redraw()
end

function crs_pressed()
    crs_selected = true
    hdg_selected = false
    redraw()
end

function dial_in(direction)
    if hdg_selected then
        if direction == 1 then hdg_bug = (hdg_bug + 1) % 360
        elseif direction == -1 then hdg_bug = (hdg_bug - 1 + 360) % 360 end
    elseif crs_selected then
        if direction == 1 then course = (course + 1) % 360
        elseif direction == -1 then course = (course - 1 + 360) % 360 end
    end
    redraw()
end

function dial_out(direction)
    -- For future expansion
end

function button_pressed()
    print("button")
end

-- Utility: map MSFS nav mode integer to text
function get_nav_mode_text(mode_int)
    local modes = {
        [0] = "ENR",
        [1] = "TERM",
        [2] = "APR",
        [3] = "LPV",
        [4] = "LNAV",
        [5] = "LNAV+V",
        [6] = "L/VNAV",
        [7] = "LP",
        [8] = "L/RNAV",
        [9] = "MAP",
        [10] = "OCS",
        [11] = "LOC",
        [12] = "VOR",
        [13] = "MISS"
    }
    return modes[mode_int] or ""
end

if TEST_MODE then
    function test_anim()
        nav_mode = get_nav_mode_text(0)
        heading = (heading + 0.7) % 360
        hdg_bug = (hdg_bug + 0.5) % 360
        course = (course + 0.3) % 360
        cdi_deflection = 0--math.sin(heading * math.pi / 180) * 2
        dis = 14.7
        ete = "06:05"
        nav_mode = "LPV"
        -- Simulate TO/FROM flag switch
        if math.sin(heading * math.pi / 180) > 0 then
            cdi_flag = 1 -- TO
        else
            cdi_flag = 2 -- FROM
        end
        redraw()
    end
    timer_start(0, 0.03, test_anim)
else
    fs2020_variable_subscribe(
        "PLANE HEADING DEGREES TRUE", "Degrees",
        "AUTOPILOT HEADING BUG", "Degrees",
        "NAV1 OBS", "Degrees",
        "GPS WP NEXT WP BEARING", "Degrees",
        "NAV SELECTED SOURCE", "Enum",
        "NAV1 CDI", "Number",
        "NAV1 TO/FROM", "Enum",
        "GPS WP DISTANCE", "Meters",
        "GPS WP ETE", "Seconds",
        "GPS APPROACH APPROACH TYPE", "Enum", -- nav mode integer
        function(hdg, hdgBug, navObs, gpsCourse, navSource, cdi, tofrom, gpsDist, gpsEte, approachType)
            heading = hdg
            hdg_bug = hdgBug
            cdi_deflection = cdi
            cdi_flag = tofrom -- 1=TO, 2=FROM
            dis = gpsDist / 1852.0 -- convert meters to nautical miles
            local min = math.floor(gpsEte / 60)
            local sec = math.floor(gpsEte % 60)
            ete = string.format("%02d:%02d", min, sec)
            nav_mode = get_nav_mode_text(approachType)
            if navSource == 3 then
                course = gpsCourse
                source = "GPS"
                course_color = magenta
            elseif navSource == 1 then
                course = navObs
                source = "VOR 1"
                course_color = green
            elseif navSource == 2 then
                course = navObs
                source = "VOR 2"
                course_color = green
            elseif navSource == 4 then
                course = navObs
                source = "LOC"
                course_color = green
            else
                course = navObs
                source = "VOR"
                course_color = green
            end
            redraw()
        end
    )
end

button_hdg = button_add(nil, nil, 86, 232, 38, 33, hdg_pressed)
button_crs = button_add(nil, nil, 198, 232, 38, 33, crs_pressed)
knob_outer = dial_add("rotary_outer.png", 5, 255, 60, 60, dial_out)
knob_inner = dial_add("knob_inner.png", 15, 265, 40, 40, dial_in)
button = button_add(nil, nil, 20, 270, 20, 20, button_pressed)