-- Air Manager GI-275 Attitude Indicator (AM Canvas API) with Heading Arc, Airspeed Tape, Altitude Tape, Horizontal Heading Tape, and Vertical Speed Box

local W, H = 320, 320
local TEST_MODE = false

local timer_cnt = 0
local flash_state = false
--user can change the default Vspeeds in Air Manager
vS_prop = user_prop_add_integer("vS", 0, 200, 54, "Stall Speed, no flaps (green arc)")
local vS = user_prop_get(vS_prop)
vS0_prop = user_prop_add_integer("vS0", 0, 200, 49, "Stall Speed, full flaps (white arc)")
vS0 = user_prop_get(vS0_prop)
vFE_prop = user_prop_add_integer("vFE", 0, 200, 86, "Max Flap Speed (white arc)")
vFE = user_prop_get(vFE_prop)
vR_prop = user_prop_add_integer("vR", 0, 200, 52, "Rotation speed")
vR = user_prop_get(vR_prop)
vX_prop = user_prop_add_integer("vX", 0, 200, 61, "Best angle of climb speed")
vX = user_prop_get(vX_prop)
vY_prop = user_prop_add_integer("vY", 0, 200, 78, "Best rate of climb speed")
vY = user_prop_get(vY_prop)
maxNO_prop = user_prop_add_integer("maxNO", 0, 200, 139, "Maximum Normal Operating (start of yellow arc")
maxNO = user_prop_get(maxNO_prop)
vNE_prop = user_prop_add_integer("vNE", 0, 200, 159, "Never Exceed speed (red line)")
vNE = user_prop_get(vNE_prop)
red_max_prop = user_prop_add_integer("redTop", 0, 200, 160, "top of the red arc")
red_max = user_prop_get(red_max_prop)

local sky = "deepskyblue"
local ground = "#b8865b"
local white = "white"
local black = "black"
local yellow = "#f2e200"
local magenta = "#e049b0"
local orange = "#fa8a00"
local dark_grey = "#404040"
local red = "#ff0000"
local green = "#00ff00"
local cyan = "#00eaff"
local light_grey = "#D9D9D9"

local sel = 0 -- 0 none, 1 baro, 2 hdg, 3 spd, 4 alt

local pitch, bank, heading = 0, 0, 0
local pitch_offset = 0---2.7--the c182 pitch on the ground is -2.7
local ias = 0
local altitude = 0
local baro_setting = 29.92 -- default baro inHg

local vs = 0 -- vertical speed, feet per minute
local FPV_hide = false
local fpv_pitch = 0   -- degrees, nose up (+), down (-)
local fpv_yaw   = 0   -- degrees, right (+), left (-)
local yaw_slip = 0     -- degrees or unitless, depending on sim variable (positive = right)

-- Global wind variables
wind_dir = 0
wind_vel = 0

-- === VERTICAL CDI variables ===
local vnav_source = ""
local vnav_cdi_deviation = 0
local vnav_cdi_valid = false
local vnav_is_gp = false -- GP or GS

--local horizon_img = img_add("horizon.png", -160, -160, 640, 640)  -- 640x640 image centered over 320x320 gauge
--ladder_img = img_add("pitch ladder.png", 0, 0, 320, 1000)
img_horizon_back = img_add("horizonbackground.png", -115, -273, 800, 1200)
img_horizon_numb = img_add("horizonnumbers.png", 149, -673, 150, 2000)

local smoothed_airspeed_trend = 0
local smoothed_altitude_trend = 0
local trend_smoothing_factor = 0.2 -- range: 0 (no smooth) .. 1 (max smooth; typical: 0.1..0.3)

-- Bugs
local airspeed_bug = 50
local altitude_bug = 0
local heading_bug = 0

local ap_vs_ft = 0  -- autopilot vertical speed ft/min

-- Mode variables (text to display)
local lateral_mode = ""
local autopilot_mode = ""
local pitch_mode = ""

-- Mode variables (text to display)
local lateral_mode = ""
local autopilot_mode = ""
local pitch_mode = ""
local armed_lateral_mode = ""
local armed_pitch_mode = ""

-- Mode positions for overlay text
local mode_bar_y = 220 -- vertical position of grey bar
local mode_bar_h = 28
local mode_lateral_x = 75    -- Green lateral mode
local mode_ap_x      = 110   -- AP or flight director mode (center of bar)
local mode_pitch_x   = 180   -- Green pitch mode
local armed_lateral_x = 40   -- White armed lateral, left of green lateral
local armed_pitch_x  = 225   -- White armed pitch, right of green pitch

local altitude_alert_state = "none"   -- "none", "approach_1000", "approach_200", "deviation", "min_alert_100", "min_alert_reached"
local alert_timer = 0
local ALERT_FLASH_DURATION = 5.0      -- seconds to flash
local last_selected_altitude = 0
local min_altitude = 0                -- crew-defined minimum
local min_altitude_source = "baro"    -- "baro" or "radio"
local min_bug_enabled = false         -- set by UI/menu/button

-- NAV/CDI variables
local nav_source = ""
local nav_source_index = 1
local nav_cdi_deviation = 0
local nav_cdi_valid = false
local nav_is_gps = false

-- Global variables to store previous values and time
local prev_ias = nil
local prev_altitude = nil
local prev_trend_time = nil

local computed_airspeed_trend = 0
local computed_altitude_trend = 0

local trend_prediction_seconds = 10  -- How many seconds ahead to predict

function draw_wind_arrow()

    if wind_vel == nil or wind_vel < 0.1 then return end

    local cx, cy = 80, 200
    local rel_dir = (wind_dir - heading + 180) % 360
    local theta = math.rad(rel_dir)
    
    local arrow_len = 6
    local arrow_width = 1
    local arrow_head_len = 3
    local arrow_head_width = 3

    -- Calculate shaft start and end (centered at cx, cy)
    local dx = math.sin(theta)
    local dy = -math.cos(theta)

    -- Snap tiny values to zero to eliminate skew
    if math.abs(dx) < 1e-12 then dx = 0 end
    if math.abs(dy) < 1e-12 then dy = 0 end

    local start_x = cx - (arrow_len/2) * dx
    local start_y = cy - (arrow_len/2) * dy
    local end_x   = cx + (arrow_len/2) * dx
    local end_y   = cy + (arrow_len/2) * dy

    -- Draw shaft
    _move_to(start_x, start_y)
    _line_to(end_x, end_y)
    _stroke("white", arrow_width)

    -- Draw arrow head at end
    local head_angle = theta
    local left = head_angle + math.rad(135)
    local right = head_angle - math.rad(135)
    local tip_x = end_x + arrow_head_len * dx
    local tip_y = end_y + arrow_head_len * dy
    local left_x = end_x + arrow_head_width * math.sin(left)
    local left_y = end_y - arrow_head_width * math.cos(left)
    local right_x = end_x + arrow_head_width * math.sin(right)
    local right_y = end_y - arrow_head_width * math.cos(right)
    _move_to(tip_x, tip_y)
    _line_to(left_x, left_y)
    _line_to(right_x, right_y)
    _line_to(tip_x, tip_y)
    _fill("white")

    local txt_x = cx + 15
    local txt_y = cy + 5
    _txt(
        string.format("%d kt", math.floor(wind_vel + 0.5)),
        "size:10; font:arimo_bold.ttf; color:white; halign:center; valign:center",
        txt_x, txt_y-5, 40, 20
    )
end

function draw_vertical_CDI()
    if not v_cdi_img then return end

    local img_top = 133
    local cdi_bar_x = 175
    local cdi_center = 160
    local dot_radius = 7

    -- Adjust these to match your gauge
    local dot_spacing = 12    -- pixels per dot (use your actual gauge measurement!)
    local deg_per_dot = 0.5   -- degrees per dot (GS standard; change for GPS if needed)
    local max_dots = 2 / deg_per_dot   -- full scale in dots (usually 5 dots for GS)
    local min_y = cdi_center - (dot_spacing * max_dots) + 5 -- top edge
    local max_y = cdi_center + (dot_spacing * max_dots) -- bottom edge

    if vnav_cdi_valid then
        visible(v_cdi_img, true)
        move(v_cdi_img, cdi_bar_x-11, img_top)

        local deviation_in_dots = vnav_cdi_deviation / deg_per_dot
        deviation_in_dots = math.max(-max_dots, math.min(max_dots, deviation_in_dots)) -- deviation clamped for label

        -- Compute unclamped shape_y, then clamp for drawing
        local unclamped_shape_y = cdi_center - (dot_spacing * (vnav_cdi_deviation / deg_per_dot))
        local shape_y = math.max(min_y, math.min(max_y, unclamped_shape_y))
        local shape_x = cdi_bar_x + 64

        -- Draw on canvas
        if vnav_is_gp then
            if pitch_mode == "VNAV" then
                -- Magenta left-pointing "V"
                local v_size = dot_radius * 1.5
                local shift_x = -7
                _move_to(shape_x + shift_x, shape_y)
                _line_to(shape_x + shift_x + v_size, shape_y - v_size/2)
                _move_to(shape_x + shift_x, shape_y)
                _line_to(shape_x + shift_x + v_size, shape_y + v_size/2)
                _stroke("magenta", 2)
            else
                -- Magenta diamond (GP)
                local diamond_size = dot_radius-1
                _move_to(shape_x, shape_y - diamond_size) -- top
                _line_to(shape_x + diamond_size, shape_y) -- right
                _line_to(shape_x, shape_y + diamond_size) -- bottom
                _line_to(shape_x - diamond_size, shape_y) -- left
                _line_to(shape_x, shape_y - diamond_size) -- top (close)
                _stroke("magenta", 3)
            end
        else
            -- Green diamond (GS)
            local diamond_size = dot_radius-1
            _move_to(shape_x, shape_y - diamond_size) -- top
            _line_to(shape_x + diamond_size, shape_y) -- right
            _line_to(shape_x, shape_y + diamond_size) -- bottom
            _line_to(shape_x - diamond_size, shape_y) -- left
            _line_to(shape_x, shape_y - diamond_size) -- top (close)
            _stroke("green", 3)
        end

        -- Source label
        local src_color = "green"
        local src_text = "G"
        if vnav_is_gp or pitch_mode == "VNAV" then
            src_color = "magenta"
            if pitch_mode == "VNAV" then
                src_text = "V"
            end
        end
        _txt(
            src_text,
            "size:14; font:arimo_bold.ttf; color:" .. src_color .. "; halign:center; valign:top",
            cdi_bar_x+64, img_top-44, 35, 16
        )
    else
        visible(v_cdi_img, false)
    end
end

function new_vertical_cdi(src_type, cdi_deviation, valid)
    vnav_source = src_type or ""
    vnav_cdi_deviation = cdi_deviation or 0
    vnav_cdi_valid = valid or false
    vnav_is_gp = (vnav_source == "GP" or vnav_source == "GS")
    if canvas_id then
        refresh()
    end
end

function draw_CDI()
    if not cdi_img then return end

    local cdi_bar_left = 106
    local cdi_bar_width = 240
    local cdi_bar_y = 208
    local cdi_bar_h = 14
    local dot_radius = 7
    

    if nav_cdi_valid then
        visible(cdi_img, true)
        move(cdi_img, cdi_bar_left-41, cdi_bar_y)

        -- Scale so that nav_cdi_deviation = ±1.0 is full edge, not ±1.8
        
        local full_deflection = (cdi_bar_width / 2.6 - dot_radius)
        local scale_factor = 1.0 / 3.5  -- shrink range to ±1.0 for MSFS2020
        local dot_x = -65 + cdi_bar_left + cdi_bar_width / 2 + nav_cdi_deviation * full_deflection * scale_factor
        local dot_y = 2 + cdi_bar_y + cdi_bar_h / 2
        local dot_color = nav_is_gps and magenta or green

        _circle(dot_x, dot_y, dot_radius)
        _fill(dot_color)
        _stroke("white", 2)

        local src_text = nav_source ~= "" and (nav_source .. tostring(nav_source_index or "")) or ""
        local src_color = nav_is_gps and magenta or green
        _txt(
            src_text,
            "size:10; font:arimo_bold.ttf; color:" .. src_color .. "; halign:left; valign:center",
            cdi_bar_left-25, cdi_bar_y+8, 100, 25
        )
    else
        visible(cdi_img, false)
    end
end


-- Draw and position the flight director bars
function update_fd_display()
    if not fd_img then return end

    -- Only show FD when either AP or FD is ON
    --if (ap_master or fd_active) then
    
    if (autopilot_mode == "") then
        visible(fd_img, false)
    else-- autopilot/fd on
        
        -- FD image is 131x28, placed at (95,160)
        -- Center of FD image (for rotation): (95+65.5, 160+14)
        local fd_center_x = 95 + 65.5
        local fd_center_y = 160 + 14

        -- Move vertically by pitch: scale pitch for FD indication (tune as needed)
        local scaling_factor = 2.0 -- You may need to tune the scaling (2.0 pixels per degree is typical for a 28px bar)
        local pitch_pixels = -2+(fd_pitch - pitch) * scaling_factor
        
        if pitch_pixels < -100 then pitch_pixels = -100 end
        if pitch_pixels > 50 then pitch_pixels = 50 end

        -- Move FD image: x stays at 95, y is 160 + pitch_pixels
        img_move(fd_img, 95, 160 + pitch_pixels, 131, 28)

        -- Rotate around center of FD image
        img_rotate(fd_img, -fd_bank)

        visible(fd_img, true)
    end
end

-- Functions to write bug values to MSFS2020

function set_airspeed_bug(val)
    airspeed_bug = val
    --fs2020_variable_write("AIRSPEED BUG POSITION", "Knots", val)
    fs2020_event("SIMCONNECT:AP_SPD_VAR_SET", val)
    refresh()
end

function set_altitude_bug(val)
    last_selected_altitude = val
    altitude_alert_state = "none"
    alert_timer = -10
    altitude_bug = val
    fs2020_variable_write("AUTOPILOT ALTITUDE LOCK VAR", "Feet", val)
    refresh()
end

function set_heading_bug(val)
    heading_bug = val
    fs2020_event("HEADING_BUG_SET", val)
    refresh()
end

function set_baro_bug(val)
    --baro_setting = val
    fs2020_variable_write("KOHLSMAN SETTING HG", "Inches of Mercury", val)
    refresh()
end

function dial_out(dir)
    if sel == 1 then -- baro
        if dir > 0 then
            fs2020_event("KOHLSMAN_INC")
        else
            fs2020_event("KOHLSMAN_DEC")
        end
    elseif sel == 2 then -- heading bug, large knob: 10 degree steps
        local step = 10
        heading_bug = (heading_bug + (dir > 0 and step or -step)) % 360
        set_heading_bug(heading_bug)
    elseif sel == 3 then -- airspeed bug
        local step = 5
        airspeed_bug = airspeed_bug + (dir > 0 and step or -step)
        if airspeed_bug < 0 then airspeed_bug = 0 end
        if airspeed_bug > 300 then airspeed_bug = 300 end
        set_airspeed_bug(airspeed_bug)
    elseif sel == 4 then -- altitude bug
        local step = 1000
        altitude_bug = altitude_bug + (dir > 0 and step or -step)
        if altitude_bug < 0 then altitude_bug = 0 end
        if altitude_bug > 50000 then altitude_bug = 50000 end
        set_altitude_bug(altitude_bug)
    end
    refresh()
end

function dial_in(dir)
    if sel == 1 then -- baro
        if dir > 0 then
            fs2020_event("KOHLSMAN_INC")
        else
            fs2020_event("KOHLSMAN_DEC")
        end
    elseif sel == 2 then -- heading bug, small knob: 1 degree steps
        local step = 1
        heading_bug = (heading_bug + (dir > 0 and step or -step)) % 360
        set_heading_bug(heading_bug)
    elseif sel == 3 then -- airspeed bug
        local step = 1
        airspeed_bug = airspeed_bug + (dir > 0 and step or -step)
        if airspeed_bug < 0 then airspeed_bug = 0 end
        if airspeed_bug > 300 then airspeed_bug = 300 end
        set_airspeed_bug(airspeed_bug)
    elseif sel == 4 then -- altitude bug
        local step = 100
        altitude_bug = altitude_bug + (dir > 0 and step or -step)
        if altitude_bug < 0 then altitude_bug = 0 end
        if altitude_bug > 50000 then altitude_bug = 50000 end
        set_altitude_bug(altitude_bug)
    end
    refresh()
end

function button_pressed()
    print("pressed")
end

-- Draw chevron bug with filled color and black outline
function draw_chevron_bug(x, y, width, height, rotation_deg, color_override, clip_half)
    local fill_color = color_override or "#82e4ea"
    local stroke_color = "black"
    local stroke_thickness = 2

    local left = -width/2
    local right = width/2
    local mid_right_x = left + 0.4 * width
    local mid_right_y = 0
    local top_hump_x = right * 0.9
    local top_hump_y = -height/2
    local bot_hump_x = right * 0.9
    local bot_hump_y = height/2

    local shape = {
        {left, -height/2},
        {top_hump_x, top_hump_y},
        {mid_right_x, mid_right_y},
        {bot_hump_x, bot_hump_y},
        {left, height/2},
    }

    local function rotate_point(px, py, angle_rad)
        local cos_a = math.cos(angle_rad)
        local sin_a = math.sin(angle_rad)
        return px * cos_a - py * sin_a, px * sin_a + py * cos_a
    end

    local angle_rad = math.rad(rotation_deg or 0)
    local pts = {}
    for i, pt in ipairs(shape) do
        local rx, ry = rotate_point(pt[1], pt[2], angle_rad)
        pts[i] = {x + rx, y + ry}
    end

    if clip_half then
        local center_x = x
        local clipped_pts = {}
        for i, pt in ipairs(pts) do
            if pt[1] >= center_x then
                table.insert(clipped_pts, pt)
            end
        end
        if #clipped_pts >= 2 then
            _move_to(center_x, y)
            for i = 1, #clipped_pts do
                _line_to(clipped_pts[i][1], clipped_pts[i][2])
            end
            _line_to(center_x, y)
            _fill(fill_color)

            _move_to(center_x, y)
            for i = 1, #clipped_pts do
                _line_to(clipped_pts[i][1], clipped_pts[i][2])
            end
            _line_to(center_x, y)
            _stroke(stroke_color, stroke_thickness)
        end
    else
        _move_to(pts[1][1], pts[1][2])
        for i = 2, #pts do
            _line_to(pts[i][1], pts[i][2])
        end
        _fill(fill_color)

        _move_to(pts[1][1], pts[1][2])
        for i = 2, #pts do
            _line_to(pts[i][1], pts[i][2])
        end
        _line_to(pts[1][1], pts[1][2])
        _stroke(stroke_color, stroke_thickness)
    end
end

function draw_FPV()
    if FPV_hide then return end
    if not fpv_img then return end

    local cx, cy = 160, 160
    local fpv_img_w, fpv_img_h = 15, 15

    local px_per_pitch = 3.5
    local px_per_yaw   = 6

    -- CAP FPV pitch/yaw to avoid off-screen
    local max_fpv_pitch = 15
    if fpv_pitch < -max_fpv_pitch then fpv_pitch = -max_fpv_pitch end
    if fpv_pitch > max_fpv_pitch then fpv_pitch = max_fpv_pitch end

    local max_fpv_yaw = 15
    if fpv_yaw < -max_fpv_yaw then fpv_yaw = -max_fpv_yaw end
    if fpv_yaw > max_fpv_yaw then fpv_yaw = max_fpv_yaw end

    -- Calculate pixel offset from center
    local fpv_x = cx + fpv_yaw * px_per_yaw - fpv_img_w/2
    local fpv_y = cy - fpv_pitch * px_per_pitch - fpv_img_h/2

    img_move(fpv_img, fpv_x, fpv_y, fpv_img_w, fpv_img_h)
    img_rotate(fpv_img, bank)
    visible(fpv_img, true)
end

function draw_horizon(pitch, bank)

    pitch = -(pitch - pitch_offset)
    bank = -bank

    -- Roll the horizon (electric gyro)
    rotate(img_horizon_back, bank * -1)
    rotate(img_horizon_numb, bank * -1)
    
    -- Move the horizon pitch, background and numbers seperately (electric gyro)
    pitch_back = var_cap(pitch, -29, 29)
    pitch_numb = var_cap(pitch, -90, 90)
    radial = math.rad(bank * -1)
    
    x_b = -(math.sin(radial) * pitch_back * 10)
    y_b = (math.cos(radial) * pitch_back * 10)
    x_n = -(math.sin(radial) * pitch_numb * 10)
    y_n = (math.cos(radial) * pitch_numb * 10)
    
    move(img_horizon_back, x_b - 245, y_b - 439, nil, nil)
    move(img_horizon_numb, x_n + 83, y_n - 839, nil, nil)
end

function draw_bank()
    local y_clip = 75

    local cx, cy = 160, 220
    local radius = 200
    local arc_start = -90
    local arc_end = 90

    -- Draw tick marks for bank angles
    for ang = arc_start, arc_end, 10 do
        local a = math.rad(ang + bank) -- FIXED: rotate in the correct direction
        local is_major = ang % 30 == 0

        local tick_in = is_major and 12 or 8
        local tick_out = is_major and 14 or 10
        local tick_width = is_major and 4 or 2

        local x1 = cx + (radius - tick_in) * math.sin(a)
        local y1 = cy - (radius - tick_in) * math.cos(a)
        local x2 = cx + (radius + tick_out) * math.sin(a)
        local y2 = cy - (radius + tick_out) * math.cos(a)
        if y1 < y_clip and y2 < y_clip then
            _move_to(x1, y1)
            _line_to(x2, y2)
            _stroke(white, tick_width)
        end
    end

    -- Draw little airplanes at ±15° positions
    local airplane_angles = {-15, 15}
    local airplane_radius = radius
    for _, ang in ipairs(airplane_angles) do
        local a = math.rad(ang + bank) -- FIXED: rotate in the correct direction
        local ax = cx + airplane_radius * math.sin(a)
        local ay = cy - airplane_radius * math.cos(a)

        -- Draw simple airplane: fuselage and wings
        local fuselage_len = 10
        local wing_span = 17
        local body_thick = 2.3

        -- Fuselage (vertical)
        _move_to(ax, ay-fuselage_len/2)
        _line_to(ax, ay+fuselage_len/2)
        _stroke(white, body_thick)

        -- Wings (horizontal)
        _move_to(ax-wing_span/2, ay)
        _line_to(ax+wing_span/2, ay)
        _stroke(white, body_thick)

        -- Nose triangle
        local nose_len = 6
        local nose_angle = math.rad(ang + bank) -- FIXED
        local nx = ax + nose_len * math.sin(nose_angle)
        local ny = ay - nose_len * math.cos(nose_angle)
        _triangle(ax, ay-fuselage_len/2, ax-3, ay-fuselage_len/2+5, ax+3, ay-fuselage_len/2+5)
        _fill(white)
    end

    -- Draw bank pointer triangle
    local tri_w = 20
    local tri_h = 30
    local tri_radius = cy - 5
    local tri_angle = math.rad(bank) -- FIXED

    local tri_pts = {
        {0, tri_h},
        {-tri_w/2, 0},
        {tri_w/2, 0},
    }

    local tri_cx = cx + tri_radius * math.sin(tri_angle)
    local tri_cy = cy - tri_radius * math.cos(tri_angle)

    local function rotate(x, y, theta)
        local cos_t = math.cos(theta)
        local sin_t = math.sin(theta)
        return x * cos_t - y * sin_t, x * sin_t + y * cos_t
    end

    local tri_rot = math.rad(bank) -- FIXED
    local px1, py1 = rotate(tri_pts[1][1], tri_pts[1][2], tri_rot)
    local px2, py2 = rotate(tri_pts[2][1], tri_pts[2][2], tri_rot)
    local px3, py3 = rotate(tri_pts[3][1], tri_pts[3][2], tri_rot)

    px1 = px1 + tri_cx; py1 = py1 + tri_cy
    px2 = px2 + tri_cx; py2 = py2 + tri_cy
    px3 = px3 + tri_cx; py3 = py3 + tri_cy

    if py1 < y_clip and py2 < y_clip and py3 < y_clip then
        _triangle(px1, py1, px2, py2, px3, py3)
        _fill(white)
    end
end

-------AIRSPEED FUNCTIONS------
local angle_offset = 25--8 -- degrees, tweak as needed


function draw_airspeed_trend(ias, airspeed_trend)
    -- Only show if trend is significant
    if math.abs(airspeed_trend) < 0.1 then return end

    local tape_radius = 125
    local arc_start = 140
    local arc_end = 220
    local cx, cy = 148, 160
    local offset_x = 10

    local prediction_seconds = 10 -- Change to 10 seconds

    -- Center tape on current IAS
    local knots_span = 60
    local knots_top = ias + (knots_span / 2)
    local knots_bot = ias - (knots_span / 2)

    -- Calculate future IAS
    local future_ias = ias + airspeed_trend * prediction_seconds
    -- Clamp to tape range
    future_ias = math.max(knots_bot, math.min(knots_top, future_ias))

    -- Find arc direction: from ias to future_ias
    local frac0 = (ias - knots_bot) / (knots_top - knots_bot)
    local frac1 = (future_ias - knots_bot) / (knots_top - knots_bot)

    local angle0_deg = arc_start + frac0 * (arc_end - arc_start)
    local angle1_deg = arc_start + frac1 * (arc_end - arc_start)

    -- Don't draw trend if steady
    if math.abs(angle1_deg - angle0_deg) < 1 then
        return
    end

    local steps = 10
    for i = 0, steps do
        local t = i / steps
        local angle_deg = angle0_deg + t * (angle1_deg - angle0_deg)
        local angle = math.rad(angle_deg)
        local x = cx + (tape_radius + 16) * math.cos(angle) + offset_x
        local y = cy + (tape_radius + 16) * math.sin(angle)
        if i == 0 then
            _move_to(x, y)
        else
            _line_to(x, y)
        end
    end
    _stroke("magenta", 4)
end

function draw_speed_band_arc(cx, cy, r, min_speed, max_speed, band_start, band_end, arc_start, arc_end, width, x_offset, color)
    local s1 = math.max(band_start, min_speed)
    local s2 = math.min(band_end, max_speed)
    if s2 <= s1 then return end

    local function speed_to_angle(speed)
        local frac = (speed - min_speed) / (max_speed - min_speed)
        return arc_start + frac * (arc_end - arc_start) + angle_offset
    end

    local a1 = speed_to_angle(s1)
    local a2 = speed_to_angle(s2)
    a1 = math.max(a1, arc_start + angle_offset)
    a2 = math.min(a2, arc_end + angle_offset)
    if a2 <= a1 then return end

    local steps = 80
    local pts = {}
    -- INNER EDGE: r - width
    for i = 0, steps do
        local frac = i / steps
        local ang = math.rad(a1 + frac * (a2 - a1))
        local x = cx + (r - width) * math.cos(ang) + x_offset
        local y = cy + (r - width) * math.sin(ang)
        table.insert(pts, {x, y})
    end
    -- OUTER EDGE: r
    for i = steps, 0, -1 do
        local frac = i / steps
        local ang = math.rad(a1 + frac * (a2 - a1))
        local x = cx + r * math.cos(ang) + x_offset
        local y = cy + r * math.sin(ang)
        table.insert(pts, {x, y})
    end

    _move_to(pts[1][1], pts[1][2])
    for i = 2, #pts do
        _line_to(pts[i][1], pts[i][2])
    end
    _fill(color)
end

function draw_airspeed_tape(ias)

    local tape_radius = 135
    local arc_start = 120
    local arc_end = 190
    local cx, cy = 160, 160

    local knots_span = 60
    local knots_top = ias + (knots_span / 2)
    local knots_bot = ias - (knots_span / 2)

    -- Green arc: normal operating range
    draw_speed_band_arc(cx, cy, tape_radius+6, knots_bot, knots_top, vS, vNE, arc_start, arc_end, 16, -7, green)
    -- Yellow arc: caution range
    draw_speed_band_arc(cx, cy, tape_radius+6, knots_bot, knots_top, maxNO, vNE, arc_start, arc_end, 16, -7, yellow)
    -- Red arc: never exceed
    draw_speed_band_arc(cx, cy, tape_radius+6, knots_bot, knots_top, vNE, red_max, arc_start, arc_end, 16, -7, red)
    -- White arc: flap operating range
    draw_speed_band_arc(cx, cy, tape_radius-6, knots_bot, knots_top, vS0, vFE, arc_start, arc_end, 7, -7, white)

    local offset_x = -10
    local tick_inner = tape_radius - 18
    local tick_outer_major = tape_radius + 8
    local tick_outer_minor = tape_radius + 3

    local tick_length_major = 15
    local tick_length_minor = 10

    local knots_step_major = 10
    local knots_step_minor = 5

    for k = math.floor(knots_bot / knots_step_minor) * knots_step_minor, knots_top, knots_step_minor do
        local frac = (k - knots_bot) / (knots_top - knots_bot)
        local angle_deg = arc_start + frac * (arc_end - arc_start) + angle_offset
        local angle = math.rad(angle_deg)
        local is_major = (k % knots_step_major == 0)

        local tick_length = is_major and tick_length_major or tick_length_minor
        local tick_thick = is_major and 3 or 1.5

        local tick_start = tick_inner + (is_major and 0 or (tick_length_major - tick_length_minor))
        local x1 = cx + tick_start * math.cos(angle) + offset_x
        local y1 = cy + tick_start * math.sin(angle)
        local x2 = cx + (tick_inner + tick_length_major) * math.cos(angle) + offset_x
        local y2 = cy + (tick_inner + tick_length_major) * math.sin(angle)
        _move_to(x1, y1)
        _line_to(x2, y2)
        _stroke("white", tick_thick)

        if is_major then
            local label_x = x2 + 25
            local label_y = y2
            _txt(
                tostring(k),
                "size:15; font:arimo_bold.ttf; color:white; align:right",
                label_x, label_y, 44, 10
            )
        end
    end

    draw_airspeed_trend(ias, computed_airspeed_trend)
    draw_airspeed_bug(airspeed_bug, knots_bot, knots_top, tape_radius, arc_start, arc_end)
    draw_vspeed_label(vX, knots_bot, knots_top, tape_radius, arc_start, arc_end, orange, "Vx")
    draw_vspeed_label(vY, knots_bot, knots_top, tape_radius, arc_start, arc_end, magenta, "Vy")
    draw_vspeed_label(vR, knots_bot, knots_top, tape_radius, arc_start, arc_end, cyan, "Vr")
    draw_current_ias(54, 160, 60)
end

function draw_vspeed_label(speed, knots_bot, knots_top, tape_radius, arc_start, arc_end, color, label)
    if speed < knots_bot or speed > knots_top then return end
    local cx, cy = 160, 160
    local offset_x = 10
    local frac = (speed - knots_bot) / (knots_top - knots_bot)
    local angle_deg = arc_start + frac * (arc_end - arc_start) + angle_offset
    local angle = math.rad(angle_deg)
    local x2 = cx + (tape_radius + 8) * math.cos(angle) + offset_x
    local y2 = cy + (tape_radius + 8) * math.sin(angle)

    _txt(label, "size:13; font:arimo_bold.ttf; color:"..color.."; align:center", x2, y2, 40, 30)
end

function draw_current_ias(x, y, size)
    local val = ias
    local arrow_color, txt_color

    if val >= vNE then
        arrow_color = red
        txt_color = black
    elseif val >= maxNO then
        arrow_color = yellow
        txt_color = black
    else
        arrow_color = black
        txt_color = white
    end

    -- Arrow shape
    local shape = {
        {-0.7, 0}, {-0.41, -0.15}, {-0.41, -0.222},
        {0.47, -0.222}, {0.47, -0.072}, {0.65, -0.072},
        {0.65, 0.072}, {0.47, 0.072}, {0.47, 0.222},
        {-0.41, 0.222}, {-0.41, 0.15}, {-0.7, 0}
    }
    local pts = {}
    for i, pt in ipairs(shape) do
        pts[i] = {x + pt[1]*size, y + pt[2]*size}
    end

    -- Arrow fill and border
    _move_to(pts[1][1], pts[1][2])
    for i = 2, #pts do _line_to(pts[i][1], pts[i][2]) end
    _fill(arrow_color)
    _move_to(pts[1][1], pts[1][2])
    for i = 2, #pts do _line_to(pts[i][1], pts[i][2]) end
    _stroke("black", 2)

    -- Rolling drum digits
    local ias_int = math.floor(val)
    local hundreds = math.floor(ias_int / 100)
    local tens = math.floor((ias_int % 100) / 10)
    local ones = ias_int % 10

    -- Drum effect for ones digit
    local drum_x = 60
    local drum_y = 135
    local drum_w = 24
    local drum_h = 50
    local drum_radius = 7
    local spacing = 20  -- tweak this for vertical space between digits

    -- Drum background stays black
    _rect(drum_x, drum_y, drum_w, drum_h, drum_radius)
    _fill("black")
    _stroke("white", 2)

    -- Fractional part for rolling effect
    local fraction = val - ias_int
    local ones_y = drum_y + drum_h/2 + fraction * spacing

    local prev_ones = (ones + 1) % 10    -- higher digit above
    local next_ones = (ones - 1) % 10    -- lower digit below

    -- Fade logic
    local prev_alpha = fraction         -- higher digit above, fades in
    local curr_alpha = 1.0 - fraction   -- brightest at .0
    local next_alpha = 0.3              -- lower digit below, static dim

    local function color_with_alpha(base, alpha)
        if base == "gray" then base = "#CCCCCC" end
        if base == "black" then base = "#000000" end
        if base == "white" then base = "#FFFFFF" end
        local r = tonumber(string.sub(base, 2, 3), 16)
        local g = tonumber(string.sub(base, 4, 5), 16)
        local b = tonumber(string.sub(base, 6, 7), 16)
        return string.format("#%02X%02X%02X%02X", r, g, b, math.floor(math.max(0, math.min(1, alpha))*255))
    end

    local function in_drum(y_pos)
        return (y_pos >= drum_y) and (y_pos <= drum_y + drum_h)
    end

    -- Above: higher digit (fades in as fraction increases)
    if in_drum(ones_y - spacing) then
        _txt(
            tostring(prev_ones),
            "size:14; font:arimo_bold.ttf; color:"..color_with_alpha("gray", prev_alpha).."; halign:center; valign:center",
            drum_x+10, ones_y - spacing, drum_w, 18
        )
    end
    -- Center: current ones digit (fades out as fraction increases)
    if in_drum(ones_y) then
        _txt(
            tostring(ones),
            "size:18; font:arimo_bold.ttf; color:"..color_with_alpha(txt_color, curr_alpha).."; halign:center; valign:center",
            drum_x+10, ones_y, drum_w, 18
        )
    end
    -- Below: lower digit (static dim)
    if in_drum(ones_y + spacing) then
        _txt(
            tostring(next_ones),
            "size:14; font:arimo_bold.ttf; color:"..color_with_alpha("gray", next_alpha).."; halign:center; valign:center",
            drum_x+10, ones_y + spacing, drum_w, 18
        )
    end

    -- Draw hundreds and tens digits
    local main_str = ""
    if hundreds > 0 then
        main_str = string.format("%d%d", hundreds, tens)
    else
        main_str = string.format("%d", tens)
    end
    _txt(
        main_str,
        "size:25; font:arimo_bold.ttf; color:"..txt_color.."; halign:right; valign:center",
        60, 160, 40, 30
    )
end

function draw_airspeed_bug(bug_speed, knots_bot, knots_top, tape_radius, arc_start, arc_end)
    if bug_speed < knots_bot or bug_speed > knots_top then return end

    local cx, cy = 160, 160     -- MATCH tape's center
    local offset_x = -15        -- MATCH tape's offset
    local bug_radius = tape_radius - 10   -- MATCH tape tick's radius
    -- Use the same angle_offset as the tape
    local angle_offset = 25     

    local frac = (bug_speed - knots_bot) / (knots_top - knots_bot)
    local angle_deg = arc_start + frac * (arc_end - arc_start) + angle_offset
    local angle_rad = math.rad(angle_deg)

    local bug_x = cx + bug_radius * math.cos(angle_rad) + offset_x
    local bug_y = cy + bug_radius * math.sin(angle_rad)
    -- If your chevron should be centered, don't subtract 5 from bug_x
    draw_chevron_bug(bug_x, bug_y, 15, 25, angle_deg + 180)
end


--draw altitude stuff

-- Utility function for timer (call in your update loop)
function update_alert_timer(dt)
    if alert_timer > 0 then
        alert_timer = alert_timer - dt
        if alert_timer < 0 then alert_timer = 0 end
    end
end

-- Call this whenever min altitude is set or changed
function set_min_altitude(val, source)
    min_altitude = val
    min_altitude_source = source or "baro"
    min_bug_enabled = true
end

function reset_min_bug()
    min_bug_enabled = false
    min_altitude = 0
end

-- Main alert logic (call in attitude update or redraw)
function update_altitude_alerts()

    -- Altitude Alerting
    local alt_diff = math.abs(altitude - altitude_bug)
    if altitude_bug ~= last_selected_altitude then
        last_selected_altitude = altitude_bug
        altitude_alert_state = "none"
        alert_timer = 0
    end
    
    if math.abs(altitude - altitude_bug) > 1000 then
        altitude_alert_state = "none"
        alert_timer = 0
    --currently moving the altitude bug   
    elseif alert_timer < 0 then
        alert_timer = alert_timer + 1--count to zero
    -- Approaching selected altitude
    elseif alt_diff <= 1000 and alt_diff > 200 and altitude_alert_state ~= "approach_1000" then
        altitude_alert_state = "approach_1000"
        alert_timer = ALERT_FLASH_DURATION
        -- (trigger aural alert here if desired)
    elseif alt_diff <= 200 and altitude_alert_state ~= "approach_200" and altitude_alert_state ~= "deviation" then
        altitude_alert_state = "approach_200"
        alert_timer = ALERT_FLASH_DURATION
        -- (trigger aural alert here if desired)
    elseif math.abs(altitude - altitude_bug) > 200 and altitude_alert_state == "none" then
        -- Deviation beyond 200 ft after reaching selected altitude
        altitude_alert_state = "deviation"
        alert_timer = ALERT_FLASH_DURATION
        -- (trigger aural alert here if desired)
    elseif math.abs(altitude - altitude_bug) <= 200 and altitude_alert_state == "deviation" then
        altitude_alert_state = "none"
        alert_timer = 0
    end

    -- Minimum Altitude Alerting
    if min_bug_enabled then
        local min_diff = altitude - min_altitude
        if min_diff < -100 and altitude_alert_state ~= "min_alert_100" then
            altitude_alert_state = "min_alert_100"
            alert_timer = 0
        elseif min_diff >= -100 and min_diff < 0 and altitude_alert_state ~= "min_alert_100" then
            altitude_alert_state = "min_alert_100"
            alert_timer = ALERT_FLASH_DURATION
            -- (visual bug goes white, can trigger aural alert "Approaching minimums")
        elseif min_diff >= 0 and altitude_alert_state ~= "min_alert_reached" then
            altitude_alert_state = "min_alert_reached"
            alert_timer = ALERT_FLASH_DURATION
            -- (bug yellow, aural "Minimums Minimums")
        end
    end
end

-- Call this in your redraw loop to update the timer
function alerting_timer_tick(dt)
    update_alert_timer(dt)
    refresh()
end

-- Example: Draw the altitude bug with color and alert state
function draw_altitude_bug_with_alert(bug_alt, alt_bot, alt_top, tape_radius, arc_start, arc_end, offset_x)
    if bug_alt < alt_bot or bug_alt > alt_top then return end
    local cx, cy = 160, 160
    local bug_radius = tape_radius + 18
    local frac = (bug_alt - alt_bot) / (alt_top - alt_bot)
    local angle_deg = arc_start + frac * (arc_end - arc_start)
    local angle_rad = math.rad(angle_deg)
    local bug_x = cx + bug_radius * math.cos(angle_rad) + offset_x
    local bug_y = cy + bug_radius * math.sin(angle_rad)

    local bug_color = cyan
    if altitude_alert_state == "deviation" then
        bug_color = yellow
    end
    draw_chevron_bug(bug_x-25, bug_y-2, 15, 24, angle_deg + 180, bug_color)
end

-- Example: Draw the minimums bug with color/state
function draw_minimums_bug()
    if not min_bug_enabled or min_altitude == 0 then return end
    -- Similar logic to altitude bug, but different color rules
    local tape_radius = 135
    local cx, cy = 160, 160
    local offset_x = 10
    local arc_start = 40
    local arc_end = -40
    local span = 600
    local alt_center = math.floor(altitude / 100) * 100
    local alt_bot = alt_center - span / 2
    local alt_top = alt_center + span / 2

    local bug_radius = tape_radius + 30
    local min_diff = altitude - min_altitude
    local frac = (min_altitude - alt_bot) / (alt_top - alt_bot)
    local angle_deg = arc_start + frac * (arc_end - arc_start)
    local angle_rad = math.rad(angle_deg)
    local bug_x = cx + bug_radius * math.cos(angle_rad) + offset_x
    local bug_y = cy + bug_radius * math.sin(angle_rad)

    local min_bug_color = cyan
    if min_diff < -100 then
        min_bug_color = cyan
    elseif min_diff >= -100 and min_diff < 0 then
        min_bug_color = white
    elseif min_diff >= 0 then
        min_bug_color = yellow
    end

    draw_chevron_bug(bug_x-25, bug_y-2, 15, 24, angle_deg + 180, min_bug_color)
end

function draw_altitude_trend(altitude, altitude_trend)
    if altitude_trend == nil then return end
    -- Only show if trend is significant
    if math.abs(altitude_trend) < 1 then return end

    -- Tape geometry for the altitude tape (right side)
    local tape_radius = 135
    local arc_start = 40
    local arc_end   = -40
    local cx, cy = 160, 160
    local offset_x = -10

    local prediction_seconds = 10 -- You can tweak this

    -- Center tape at current altitude for smooth scrolling
    local span = 600
    local alt_top = altitude + (span / 2)
    local alt_bot = altitude - (span / 2)

    -- Predict future altitude
    local future_altitude = altitude + altitude_trend * prediction_seconds
    -- Clamp to tape range
    future_altitude = math.max(alt_bot, math.min(alt_top, future_altitude))

    -- Find arc direction: from current altitude to future altitude
    local frac0 = (altitude - alt_bot) / (alt_top - alt_bot)
    local frac1 = (future_altitude - alt_bot) / (alt_top - alt_bot)

    local angle0_deg = arc_start + frac0 * (arc_end - arc_start)
    local angle1_deg = arc_start + frac1 * (arc_end - arc_start)

    -- Don't draw trend if steady
    if math.abs(angle1_deg - angle0_deg) < 1 then
        return
    end

    local steps = 10
    local start_y_offset = 8 -- pixels to move the start down (adjust as needed)

    for i = 0, steps do
        local t = i / steps
        local angle_deg = angle0_deg + t * (angle1_deg - angle0_deg)
        local angle = math.rad(angle_deg)
        local x = cx + (tape_radius + 16) * math.cos(angle) + offset_x
        local y = cy + (tape_radius + 16) * math.sin(angle)
        if i == 0 then
            y = y + start_y_offset -- move starting point down
            _move_to(x, y)
        else
            _line_to(x, y)
        end
    end
    _stroke("magenta", 4) -- Altitude trend color and size
end

function draw_altitude_tape(altitude)
    local tape_radius = 135
    local cx, cy = 160, 160
    local offset_x = 10
    local arc_start = 40
    local arc_end = -40

    local step_major = 100
    local step_minor = 50
    local span = 600

    -- Use continuous center for smooth scrolling with baro changes
    local alt_center = altitude
    local alt_bot = alt_center - span / 2
    local alt_top = alt_center + span / 2

    local tick_outer = tape_radius + 8
    local tick_inner_major = tape_radius - 10
    local tick_inner_minor = tape_radius - 7

    -- Keep tick labels snapped to 100 ft intervals, positions scroll smoothly
    for k = math.floor(alt_bot / step_major) * step_major, alt_top, step_minor do
        local frac = (k - alt_bot) / (alt_top - alt_bot)
        local angle_deg = arc_start + frac * (arc_end - arc_start)
        local angle = math.rad(angle_deg)
        local is_hundred = (k % 100 == 0)
        local tick_inner = is_hundred and tick_inner_major or tick_inner_minor
        local tick_thick = is_hundred and 3 or 1.5

        local x1 = cx + tick_inner * math.cos(angle) + offset_x
        local y1 = cy + tick_inner * math.sin(angle)
        local x2 = cx + tick_outer * math.cos(angle) + offset_x
        local y2 = cy + tick_outer * math.sin(angle)
        _move_to(x1, y1)
        _line_to(x2, y2)
        _stroke("white", tick_thick)

        if is_hundred then
            local alt_txt_thousand = math.floor(k / 1000)
            local alt_txt_hundred = math.floor((k % 1000) / 100)
            local label_x = x2 - 55
            local label_y = y2 + 5

            if altitude >= 10000 then
                local ten_thousand = math.floor(alt_txt_thousand / 10)
                local thousand = alt_txt_thousand % 10
                _txt(
                    tostring(ten_thousand),
                    "size:18; font:arimo.ttf; color:white; align:left",
                    label_x+10, label_y, 18, 20
                )
                _txt(
                    tostring(thousand),
                    "size:18; font:arimo.ttf; color:white; align:left",
                    label_x+20, label_y, 18, 20
                )
                _txt(
                    tostring(alt_txt_hundred),
                    "size:12; font:arimo.ttf; color:white; align:left",
                    label_x+30, label_y+5, 15, 15
                )
            elseif altitude >= 1000 then
                _txt(
                    tostring(alt_txt_thousand),
                    "size:18; font:arimo.ttf; color:white; align:left",
                    label_x+15, label_y, 20, 20
                )
                _txt(
                    tostring(alt_txt_hundred),
                    "size:12; font:arimo.ttf; color:white; align:left",
                    label_x + 25, label_y + 5, 15, 15
                )
            else
                _txt(
                    tostring(alt_txt_hundred),
                    "size:12; font:arimo.ttf; color:white; align:left",
                    label_x+25, label_y, 15, 15
                )
            end
        end
    end

    local arrow_x = W - 40
    local arrow_y = 160
    draw_current_altitude(arrow_x, arrow_y, 50)
    draw_altitude_bug_arc(altitude_bug, alt_bot, alt_top, tape_radius, arc_start, arc_end, offset_x)
end

function draw_current_altitude(x, y, size)
    local offset_x = -12
    local shape_width = 0.7
    local shape = {
        {0.9 * shape_width, 0},
        {0.53 * shape_width, -0.15},
        {0.53 * shape_width, -0.222},
        {-0.60 * shape_width, -0.222},
        {-0.60 * shape_width, -0.072},
        {-0.85 * shape_width, -0.072},
        {-0.85 * shape_width, 0.072},
        {-0.60 * shape_width, 0.072},
        {-0.60 * shape_width, 0.222},
        {0.53 * shape_width, 0.222},
        {0.53 * shape_width, 0.15},
        {0.9 * shape_width, 0},
    }
    local pts = {}
    for i, pt in ipairs(shape) do
        pts[i] = {x + pt[1]*size + offset_x, y + pt[2]*size}
    end
    _move_to(pts[1][1], pts[1][2])
    for i = 2, #pts do
        _line_to(pts[i][1], pts[i][2])
    end
    _stroke("white", 2)
    for i = 2, #pts-1 do
        _triangle(pts[1][1], pts[1][2],
                  pts[i][1], pts[i][2],
                  pts[i+1][1], pts[i+1][2])
        _fill("black")
    end

    _txt(
        string.format("%d", math.floor(altitude)),
        "size:20; font:arimo_bold.ttf; color:white; halign:right",
        W-15 + offset_x, 149, 50, 26
    )
end

function draw_altitude_bug_arc(bug_alt, alt_bot, alt_top, tape_radius, arc_start, arc_end, offset_x)
    if bug_alt < alt_bot or bug_alt > alt_top then
        return
    end
    local cx, cy = 190, 160
    local bug_radius = tape_radius - 5-- + 18
    local frac = (bug_alt - alt_bot) / (alt_top - alt_bot)
    local bug_angle_offset = 1  -- Try different values (+/-) to align visually!
    local angle_deg = arc_start + frac * (arc_end - arc_start) + bug_angle_offset
    local angle_rad = math.rad(angle_deg)
    local bug_x = cx + bug_radius * math.cos(angle_rad) + offset_x
    local bug_y = cy + bug_radius * math.sin(angle_rad)
    draw_chevron_bug(bug_x-30, bug_y-2, 15, 24, angle_deg + 180)
end

function heading_to_text(val)
    val = math.floor(val + 0.5) % 360
    if val == 0 then
        return " N"
    elseif val == 90 then
        return " E"
    elseif val == 180 then
        return " S"
    elseif val == 270 then
        return " W"
    else
        return string.format("%03d", val)
    end
end

function draw_heading_bug(hdg_center, tape_left, tape_bottom, tape_width, tape_height)
    local span = 60
    local bug_diff = ((heading_bug - hdg_center + 540) % 360) - 180
    local frac = bug_diff / span
    local bug_x = tape_left + tape_width/2 + frac * tape_width
    local bug_y = tape_bottom - tape_height/2 - 8

    local left_limit = tape_left + 10
    local right_limit = tape_left + tape_width - 30
    local bug_w = 15
    local bug_h = 25

    local half_w = bug_w / 2

    local clip_half = false
    if bug_x < left_limit + half_w then
        bug_x = left_limit + half_w
        clip_half = true
    elseif bug_x > right_limit - half_w then
        bug_x = right_limit - half_w
        clip_half = true
    end

    draw_chevron_bug(bug_x, bug_y+20, bug_w, bug_h, 90, cyan, clip_half)

    if sel == 2 then
        local bug_val_str = string.format("%03d", math.floor(heading_bug) % 360)
        _txt(bug_val_str, "size:22; font:arimo_bold.ttf; color:"..cyan.."; align:center", bug_x - 20, bug_y, 40, 22)
    end
end

function draw_heading_tape(hdg)
    local tape_left = 35
    local tape_bottom = H - 65
    local tape_width = W - 70
    local tape_height = 40

    local span = 60
    local deg_step_major = 10
    local deg_step_minor = 5

    local hdg_center = hdg % 360
    
    
    --draw black background for nav source text
    _rect(0, 270, 320, 50)
    _fill(black)
    
    --black background for tape background
    _rect(tape_left, tape_bottom - tape_height/2, tape_width, tape_height, 8)
    _fill(black)

    for d = -span/2, span/2, deg_step_minor do
        local hdg_tick = (hdg_center + d + 360) % 360
        local x = tape_left + tape_width/2 + (d / span) * tape_width

        local is_major = d % deg_step_major == 0
        local is_label = (hdg_tick % 30 == 0) or (hdg_tick == 0)

        if x > tape_left and x < tape_left + tape_width then
            if is_major then
                _move_to(x, tape_bottom - tape_height/2 + 6)
                _line_to(x, tape_bottom + tape_height/2 - 6)
                _stroke(white, 3)

                if is_label then
                    local heading_text = heading_to_text(hdg_tick)
                    local label_w = 32
                    local label_h = 22
                    local box_pad = 6
                    local box_w = label_w + box_pad
                    local box_h = label_h
                    local box_x = x - box_w/2
                    local box_y = tape_bottom - tape_height/2 + 15

                    _rect(box_x, box_y, box_w, box_h, 6)
                    _fill(black)
                    _txt(heading_text, "size:22; font:arimo_bold.ttf; color:white; align:center",
                         x - label_w/2 + 5, box_y, label_w, label_h)
                end
            else
                _move_to(x, tape_bottom - 7)
                _line_to(x, tape_bottom + 7)
                _stroke(white, 2)
            end
        end
    end

    local pointer_x = tape_left + tape_width/2
    local box_w = 44
    local box_h = 20
    local box_y = (tape_bottom - tape_height/2) + 20

    _rect((pointer_x - box_w/2)-1, box_y-1, box_w+2, box_h+2, 7)
    _fill(white)

    _rect(pointer_x - box_w/2, box_y, box_w, box_h, 7)
    _fill(black)
    
    local hdg_val = math.floor(hdg_center + 0.5) % 360
    local hdg_num = hdg_val == 0 and "360" or string.format("%03d", hdg_val)
    _txt(hdg_num, "size:22; font:arimo_bold.ttf; color:white; align:center",
         pointer_x - box_w/2 + 5, box_y-1, box_w, box_h - 2)

    draw_heading_bug(hdg_center, tape_left, tape_bottom, tape_width, tape_height)
end

function update_baro_display()
    baro_setting = math.floor(baro_setting * 100 + 0.5) / 100
    local s_baro = baro_setting
    if string.len(s_baro) == 4 then s_baro = s_baro.."0" end
    s_baro = s_baro.. "in"
    txt_set(baro_txt_overlay, s_baro)
end

function update_hdg_display()
    local s_hdg
    local hdg = math.floor(heading_bug)
    if heading_bug < 10 then
        s_hdg = "00" .. hdg .. "°"
    elseif heading_bug < 100 then
        s_hdg = "0" .. hdg .. "°"
    else
        s_hdg = hdg .. "°"
    end
    txt_set(hdg_txt_overlay, s_hdg)
end

function update_spd_display()
    txt_set(spd_txt_overlay, math.floor(airspeed_bug))
end

function update_alt_display()

    local flash_on = (alert_timer > 0 and math.floor(alert_timer * 3) % 2 == 0)
    local txt_color = cyan -- Default color

    -- Hide by default
    visible(alt_alert_img, false)

    if altitude_alert_state == "approach_1000" or altitude_alert_state == "approach_200" then
        if flash_on then
            visible(alt_alert_img, true)  -- Show PNG
            txt_color = "black"
        else
            visible(alt_alert_img, false)
            txt_color = cyan
        end
    elseif altitude_alert_state == "deviation" then
        if flash_on then
            txt_color = "yellow"
        else
            txt_color = cyan
        end
    else
        visible(alt_alert_img, false)
        txt_color = cyan
    end

    txt_style(alt_txt_overlay, "color:"..txt_color..";")
    txt_set(alt_txt_overlay, string.format("%d", math.floor(altitude_bug)))
end

-- VS BOX CODE
function update_vs_display()
    local vs_k = vs / 1000.0
    local arrow = ""
    local display_vs = math.abs(vs_k)
    local display_str = string.format("%.1f", display_vs)
    local bg_color

    if vs >= -50 then
        arrow = "↑"
        bg_color = dark_grey
    else
        arrow = "↓"
        bg_color = "red"
    end

    -- Example box position/size, adjust to your overlay
    local x, y, w, h = 235, 173, 40, 18  -- (left, top, width, height)
    _rect(x, y, w, h, 7) -- Draw background box first
    _fill(white)
    _rect(x+1, y+1, w-2, h-2, 7) -- Draw background box first
    _fill(bg_color)

    txt_set(vs_txt_overlay, arrow .. " " .. display_str) -- Then set text
end

function draw_yaw()

    -- Center of gauge
    local cx, cy = 160, 59

    -- Line geometry
    local line_length = 15
    local line_thickness = 4

    -- Slide factor: how many pixels per unit of yaw/slip/skid
    local px_per_unit = 30   -- tune as needed for realism

    -- Calculate slide (positive slip = right, negative = left)
    local slide_x = yaw_slip * px_per_unit

    -- Calculate endpoints (horizontal line centered, then shifted)
    local x1 = cx - line_length/2 + slide_x
    local y1 = cy
    local x2 = cx + line_length/2 + slide_x
    local y2 = cy

    -- Rotate about center by -bank (reverse bank)
    local angle = 0--math.rad(-bank)
    local function rotate_point(x, y, cx, cy, a)
        local dx, dy = x - cx, y - cy
        local rx = dx * math.cos(a) - dy * math.sin(a)
        local ry = dx * math.sin(a) + dy * math.cos(a)
        return cx + rx, cy + ry
    end

    local rx1, ry1 = rotate_point(x1, y1, cx, cy, angle)
    local rx2, ry2 = rotate_point(x2, y2, cx, cy, angle)

    _move_to(rx1, ry1)
    _line_to(rx2, ry2)
    _stroke("white", line_thickness)
end

-- In redraw, call update_fd_display() after drawing everything else
function redraw()

    if canvas_clip_circle then
        canvas_clip_circle(W/2, H/2, W/2-2)
    end

    -- Draw main layers
    draw_horizon(pitch, bank)
    draw_FPV() -- this might have to be done manually
    draw_airspeed_tape(ias)
    
    -- Update alerts and draw altitude tape (includes bug/minimums)
    update_altitude_alerts()
    draw_minimums_bug()
    draw_altitude_tape(altitude)
    draw_altitude_trend(altitude, computed_altitude_trend)
    draw_heading_tape(heading)
    draw_wind_arrow()
    draw_bank()
    draw_yaw()
    draw_CDI()
    draw_vertical_CDI()
    update_fd_display()

    -- Update overlays/texts
    if (canvas_id) then
        update_baro_display()
        update_hdg_display()
        update_spd_display()
        update_alt_display()         -- will update alt_txt_overlay appearance (color/flash)
        update_vs_display()
        update_modes_display()
        

        visible(foreground_img, true)

        -- Selection highlighting overlays
        visible(sel_baro, sel == 1)
        visible(sel_hdg, sel == 2)
        visible(sel_spd, sel == 3)
        visible(sel_alt, sel == 4)
    end
end

-- Update text overlays (now with armed modes)
function update_modes_display()
    local pitch_display = pitch_mode
    if pitch_mode == "VS" then
        local arrow = ""
        local vs_value = math.abs(ap_vs_ft)
        if ap_vs_ft > 0 then
            arrow = "↑"
        elseif ap_vs_ft < 0 then
            arrow = "↓"
        end
        -- Convert feet per minute to thousands, rounded to one decimal, and take 3 chars max
        local vs_str = string.format("%.1f", vs_value / 1000)
        if #vs_str > 3 then
            vs_str = string.sub(vs_str, 1, 3)
        end
        pitch_display = pitch_mode .. " " .. arrow .. vs_str
    elseif pitch_mode == "IAS" then
        pitch_display = pitch_mode .. " " .. tostring(math.floor(airspeed_bug))
    end

    txt_set(lateral_mode_txt, lateral_mode)
    txt_set(ap_mode_txt, autopilot_mode)
    txt_set(pitch_mode_txt, pitch_display)
    txt_set(armed_lateral_mode_txt, armed_lateral_mode)
    txt_set(armed_pitch_mode_txt, armed_pitch_mode)
end

function refresh()
    if timer_cnt > 0 then
        canvas_draw(canvas_id, function() redraw() end)
    end  
end

function new_attitude(p, b, h, a, baro, vert_speed)
    pitch, bank, heading, altitude = p, b, h, a
    baro_setting = baro
    vs = vert_speed or vs
    refresh()
end

-- Call this in your timer (every 0.1s or 0.5s)
function update_trend_predictions()
    local now = os.clock()
    if prev_trend_time == nil then
        prev_trend_time = now
        prev_ias = ias
        prev_altitude = altitude
        return
    end

    local dt = now - prev_trend_time
    if dt < 0.2 then return end -- Only update every ~0.2s minimum

    local alt_change = altitude - prev_altitude
    local raw_altitude_trend
    if math.abs(alt_change) < 0.5 then
        raw_altitude_trend = 0
    else
        raw_altitude_trend = alt_change / dt  -- feet per second
        if math.abs(raw_altitude_trend) > 100 then
            raw_altitude_trend = 0
        end
    end

    local ias_change = ias - prev_ias
    local raw_airspeed_trend
    if math.abs(ias_change) < 0.1 then
        raw_airspeed_trend = 0
    else
        raw_airspeed_trend = ias_change / dt   -- knots per second
        if math.abs(raw_airspeed_trend) > 20 then
            raw_airspeed_trend = 0
        end
    end

    -- === Add smoothing here ===
    smoothed_altitude_trend = (1 - trend_smoothing_factor) * smoothed_altitude_trend + trend_smoothing_factor * raw_altitude_trend
    smoothed_airspeed_trend = (1 - trend_smoothing_factor) * smoothed_airspeed_trend + trend_smoothing_factor * raw_airspeed_trend

    -- Save for next calculation
    prev_trend_time = now
    prev_ias = ias
    prev_altitude = altitude

    -- Update displayed values
    computed_altitude_trend = smoothed_altitude_trend
    computed_airspeed_trend = smoothed_airspeed_trend
end

function atan2(y, x)
    if x > 0 then
        return math.atan(y / x)
    elseif x < 0 then
        if y >= 0 then
            return math.atan(y / x) + math.pi
        else
            return math.atan(y / x) - math.pi
        end
    elseif y > 0 then
        return math.pi / 2
    elseif y < 0 then
        return -math.pi / 2
    else
        return 0
    end
end

-- Call this function to get predicted IAS in N seconds
function predicted_ias(seconds)
    return ias + computed_airspeed_trend * seconds
end

-- Call this function to get predicted altitude in N seconds
function predicted_altitude(seconds)
    return altitude + computed_altitude_trend * seconds
end

-- MSFS2020 subscription for Flight Director
if TEST_MODE then
    --function test_anim()
        local fake_pitch = 0
        local fake_bank = 0
        local fake_heading = 350
        local fake_ias = 51
        local fake_altitude = 3000
        local fake_vs = -500
        ias = fake_ias
        altitude = fake_altitude
        vs = fake_vs
        pitch, bank = fake_pitch, fake_bank
        wind_dir = 0
        wind_vel = 10

        -- Example modes
        lateral_mode = "HDG"
        pitch_mode = "ALT"
        autopilot_mode = "AP"
        armed_lateral_mode = "NAV"      -- Example: NAV is armed
        armed_pitch_mode = "GS"         -- Example: Glide Slope is armed

        -- Example modes
    lateral_mode = "HDG"
    pitch_mode = "ALT"
    armed_lateral_mode = "NAV"
    armed_pitch_mode = "GS"
    ap_master = 1
    fd_active = 1
    fd_pitch = 0
    fd_bank = 0
    fpv_pitch = 10
    fpv_yaw = 1
    yaw_slip = 0.7   -- positive: ball to the right (skid right)

    -- === CDI TEST VARIABLES ===
    -- Simulate a VOR1 signal, deviation full right ("one dot right")
    nav_source = "VOR"
    nav_source_index = 1
    nav_cdi_deviation = -1  -- 0.2 is roughly "one dot" (full range is -1.0 to +1.0)
    nav_cdi_valid = true
    nav_is_gps = false
    vnav_source = "GS"
    vnav_cdi_deviation = 0-- half dot low (0=on, -1=full below, +1=full above)
    vnav_cdi_valid = true
    vnav_is_gp = false
    new_vertical_cdi(vnav_source, vnav_cdi_deviation, vnav_cdi_valid)
    -- ==========================
        
        new_attitude(fake_pitch, fake_bank, fake_heading, fake_altitude, baro_setting, fake_vs)
    --end
    
    --subscriptions
else

    
    fs2020_variable_subscribe(
        "TURN COORDINATOR BALL", "Position",    -- Usually -1 (left) to +1 (right)
        function(slipSkid)
            yaw_slip = slipSkid
            refresh()
        end
    )
    
    -- Define a custom atan2 function
    function atan2(y, x)
        if x > 0 then
            return math.atan(y / x)
        elseif x < 0 then
            return math.atan(y / x) + math.pi
        elseif y > 0 then
            return math.pi / 2
        elseif y < 0 then
            return -math.pi / 2
        else
            return 0
        end
    end

    fs2020_variable_subscribe(
    "AUTOPILOT ALTITUDE LOCK VAR", "Feet",
    "ALTITUDE BUG INDICATED", "Feet",
    "ALTITUDE MINIMUM", "Feet",           -- custom variable for baro/radio minimum
    "ALTITUDE MINIMUM SOURCE", "Enum",    -- custom, 0=baro, 1=radio
    function(ap_sel, bug, min, min_source)
        set_altitude_bug(ap_sel)
        set_min_altitude(min, (min_source == 0) and "baro" or "radio")
    end
    
)

    fs2020_variable_subscribe(
        "PLANE PITCH DEGREES", "Degrees",
        "PLANE BANK DEGREES", "Degrees",
        "PLANE HEADING DEGREES MAGNETIC", "Degrees",
        "AIRSPEED INDICATED", "Knots",
        "INDICATED ALTITUDE", "Feet",
        "KOHLSMAN SETTING HG", "Inches of Mercury",
        "VERTICAL SPEED", "Feet per minute",
	"AUTOPILOT FLIGHT DIRECTOR ACTIVE", "Bool",

        function(p, b, h, s, a, baro, vert_speed,
                 fd_active_val)
            pitch, bank, heading, ias, altitude, baro_setting, vs = p, b, h, s, a, baro, vert_speed
            fd_active = fd_active_val
        end
    )
    
    
    -- Example calculation using Air Manager subscriptions
    fs2020_variable_subscribe(
    "VERTICAL SPEED", "Feet per minute",
    "RELATIVE WIND VELOCITY BODY X", "Meters per second",
    function(vs, x_wind)
        fpv_pitch = (vs / 150) + pitch

        fpv_yaw = -x_wind/2
        
        
        refresh()
    end
)

    -- Full Air Manager subscription and callback for autopilot master, lateral and pitch modes (active and armed)
    

-- Air Manager: Full autopilot mode subscription and logic for MSFS2020

fs2020_variable_subscribe(
    "AUTOPILOT MASTER", "Bool",
    "AUTOPILOT FLIGHT DIRECTOR ACTIVE", "Bool",

    "AUTOPILOT NAV1 LOCK", "Bool",              -- nav1_lock (VOR or LOC)
    "NAV HAS LOCALIZER:1", "Bool",  -- loc_active
    "AUTOPILOT BACKCOURSE ACTIVE", "Bool",      -- bc_active
    "AUTOPILOT APPROACH ACTIVE", "Bool",        -- apr_active
    "AUTOPILOT WING LEVELER", "Bool",           -- wing_leveler
    "AUTOPILOT HEADING LOCK", "Bool",           -- hdg_hold

    "GPS DRIVES NAV1", "Bool",                  -- nav_gps

    "AUTOPILOT ALTITUDE LOCK", "Bool",          -- alt_hold
    "AUTOPILOT ALTITUDE ARM", "Bool",           -- alt_arm
    "AUTOPILOT VERTICAL HOLD", "Bool",          -- ap_vs
    "AUTOPILOT FLIGHT LEVEL CHANGE", "Bool",    -- ap_ias
    "AUTOPILOT GLIDESLOPE ACTIVE", "Bool",      -- ap_gs
    "AUTOPILOT GLIDESLOPE ARM", "Bool",         -- gs_arm
    "AUTOPILOT VNAV ARM", "Bool",               -- ap_vnav_arm
    "AUTOPILOT PITCH HOLD", "Bool",             -- pitch_hold
    "AUTOPILOT APPROACH ARM", "Bool",           -- apr_arm
    "AUTOPILOT VERTICAL HOLD VAR", "Feet per minute",--ap_vs_ftmin
    "AUTOPILOT FLIGHT DIRECTOR PITCH", "Radians",--fd_p
    "AUTOPILOT FLIGHT DIRECTOR BANK", "Radians",    --fd_r
    "L:WT_TOGA_ACTIVE", "Bool",                    -- toga	
    "L:WTAP_VNav_State", "Number",                --vnav


    function(
        ap_master, fd_active,
        nav1_lock, loc_active, bc_active, apr_active, wing_leveler, hdg_hold,
        nav_gps,
        alt_hold, alt_arm, ap_vs, ap_ias, ap_gs, gs_arm, ap_vnav_arm,
        pitch_hold, apr_arm, ap_vs_ftmin, fd_p, fd_r, toga, vnav
    )
    
    
        ap_vs_ft = ap_vs_ftmin
        fd_pitch = fd_p * (180 / math.pi)
        fd_bank = fd_r * (180 / math.pi)
    
        -- AUTOPILOT MODE
        autopilot_mode = ""
        if ap_master then
            autopilot_mode = "AP"
        elseif fd_active then
            autopilot_mode = "FD"
        else
            autopilot_mode = ""
        end
        

        -- ACTIVE LATERAL MODE (with VOR disambiguation)
        lateral_mode = ""
        if hdg_hold then
            lateral_mode = "HDG"
        elseif nav1_lock or apr_active then
            if loc_active and not nav_gps then
                lateral_mode = "LOC"
            elseif nav_gps then
                lateral_mode = "GPS"
            else
                lateral_mode = "VOR"
            end
        elseif bc_active then
            lateral_mode = "BC"
        elseif apr_active then
            lateral_mode = "APR"
        elseif wing_leveler then
            lateral_mode = "ROL"
        elseif toga then
            lateral_mode = "TO"
        else
            lateral_mode = ""
        end

        -- ARMED LATERAL MODE (no explicit VOR armed mode, so only APR and NAV)
        armed_lateral_mode = ""
        if lateral_mode == "HDG" or lateral_mode == "ROL" then
            if apr_arm then
                armed_lateral_mode = "APR"
            elseif nav1_lock and not loc_active then
                armed_lateral_mode = "VOR"
            elseif nav1_lock and loc_active then
                armed_lateral_mode = "LOC"
            end
        else
            armed_lateral_mode = ""
        end
       

        -- ACTIVE PITCH MODE
        pitch_mode = ""
        if alt_hold then
            pitch_mode = "ALT"
        elseif ap_vs then
            pitch_mode = "VS"
        elseif pitch_hold then
            pitch_mode = "PIT"
        elseif ap_gs and nav_gps then
            pitch_mode = "GP"
        elseif vnav == 2 then
            pitch_mode = "VNAV"    
        elseif ap_gs and not nav_gps then
            pitch_mode = "GS"
        elseif ap_ias then
            pitch_mode = "IAS"
        elseif ap_gs then
            pitch_mode = (lateral_mode == "LOC") and "GS" or "GP"
        elseif toga then
            pitch_mode = "TO"
        else
            pitch_mode = ""
        end

        -- ARMED PITCH MODE
        armed_pitch_mode = ""
        if gs_arm and nav_gps then
            armed_pitch_mode = "GP"
        elseif gs_arm and not nav_gps then
            armed_pitch_mode = "GS"
        elseif ap_vnav_arm then
            armed_pitch_mode = "VNAV"
        elseif alt_arm then
            armed_pitch_mode = "ALT"
        else
            armed_pitch_mode = ""
        end
    end
    
)
    
    
    fs2020_variable_subscribe(
        "AUTOPILOT AIRSPEED HOLD VAR", "Knots",
        "AUTOPILOT HEADING LOCK DIR:1", "DEGREES",
        function(airspeedBug, headingBug)
            airspeed_bug = airspeedBug
            heading_bug = headingBug
            refresh()
        end
    )
    fs2020_variable_subscribe(
        "ALTITUDE BUG INDICATED", "Feet",
        function(bug)
            altitude_bug = bug
            set_altitude_bug(bug)
        end
    )
        -- Subscription for MSFS2020 wind data
    fs2020_variable_subscribe(
    "AMBIENT WIND DIRECTION", "Degrees",
    "AMBIENT WIND VELOCITY", "Knots",
    "PLANE HEADING DEGREES TRUE", "Degrees",
    function(wd, wv, hdg)
        wind_dir = wd
        wind_vel = wv
        plane_heading = hdg
        
        -- Calculate wind direction relative to aircraft
        -- Positive means wind from the right, negative from the left
        wind_relative = (wind_dir - plane_heading)
        -- Normalize to [-180, 180]
        wind_relative = ((wind_relative + 180) % 360) - 180

        if canvas_id then refresh() end
        
        
    end
)
end


--vertical CDI variables
fs2020_variable_subscribe(
    "GPS DRIVES NAV1", "Bool",                     -- gps_drives_nav1 true if GPS (or FMS) drives NAV1
    "NAV GLIDE SLOPE ERROR:1", "Degrees",          -- nav_cdi CDI deviation
    "NAV HAS GLIDE SLOPE:1", "Bool",               -- gs_active true if GS is active
    "HSI CDI NEEDLE VALID", "Bool",                -- cdi_valid valid cdi needle
    "AUTOPILOT NAV1 LOCK", "Bool",                 -- ap_nav AP nav
    "AUTOPILOT APPROACH ACTIVE", "Bool",           -- ap_apr AP apr active
    "HSI CDI NEEDLE", "Number",                    -- cdi_dev
    "GPS HAS GLIDEPATH", "Bool",                   -- gps_gp
    "GPS VERTICAL ANGLE ERROR", "Degrees",         -- gp_dev gps specific glide path error
    "L:WTAP_VNav_Vertical_Deviation", "Number",    -- vnav_deviation


    function(gps_drives_nav1, nav_cdi, gs_active, cdi_valid, ap_nav, ap_apr, cdi_dev, gps_gp, gp_dev, vnav_deviation)
    
        nav_cdi_valid = cdi_valid
        nav_is_gps = gps_drives_nav1
        nav_cdi_deviation = cdi_dev/50
        vnav_dev = vnav_deviation
        
        if ap_nav or ap_apr then
            -- VNAV SOURCE
            if gps_drives_nav1 then
                vnav_source = "GPS"
            else
                vnav_source = "NAV1"
            end
    
            -- CDI VALID
            vnav_cdi_valid = false
            
    
            -- GP/GS/TO/VNAV
            if pitch_mode == "VNAV" then
                vnav_cdi_valid = true
                vnav_cdi_deviation = vnav_deviation / 400
                vnav_is_gp = true
            elseif ap_apr then
                if gps_gp and (pitch_mode == "GP" or armed_pitch_mode == "GP") then
                    vnav_is_gp = true
                    vnav_cdi_valid = true
                    vnav_cdi_deviation = -gp_dev*2
                elseif gs_active then
                    vnav_is_gp = false
                    vnav_cdi_valid = true
                     vnav_cdi_deviation = -nav_cdi
                else
                    vnav_is_gp = false -- neither active, default to GS (or false)
                end
            end
            
        else
            vnav_cdi_valid = false
            nav_cdi_valid = false
        end
    
        

    end
)

--non FD aircraft support
si_variable_subscribe("fd_on", "bool", function(fd)
    fd_active = fd
    end)

button_baro = button_add(nil, nil, 232, 200, 70, 32, function()
    sel = 1
    if canvas_id then
        refresh()
    end
end)
button_heading = button_add(nil, nil, 24, 200, 54, 32, function()
    sel = 2
    if canvas_id then
        refresh()
    end
end)
button_airspeed = button_add(nil, nil, 24, 60, 54, 32, function()
    sel = 3
    if canvas_id then
        refresh()
    end
end)
button_altitude = button_add(nil, nil, 242, 60, 54, 32, function()
    sel = 4
    if canvas_id then
        refresh()
    end
end)

tape_shade_img = img_add("Gi-275 attitude tape shade.png", 0, 0, 320, 320)
cdi_img = img_add("Gi-275 attitude CDI.png", 0, 150, 150, 18)
visible(cdi_img, false)
-- Add image for vertical CDI
v_cdi_img = img_add("Gi-275 attitude CDI.png", 235-11, 54-6, 150, 18)
rotate(v_cdi_img, 90)
visible(v_cdi_img, false)

canvas_id = canvas_add(0, 0, W, H, function()
    redraw()
end)

fpv_img = img_add("FPV.png", 160, 100, 15, 15)
--visible(fpv_img, false)
fd_img = img_add("Gi-275 attitude FD.png", 95, 160, 131, 28)
visible(fd_img, false)  -- Hide by default
foreground_img = img_add("Gi-275 attitude overlay.png", 0, 0, 320, 320)
sel_baro = img_add("Gi-275 attitude overlay baro.PNG", 0, 4, 320, 320)
visible(sel_baro, false)
sel_hdg = img_add("Gi-275 attitude overlay hdg.PNG", 0, 4, 320, 320)
visible(sel_hdg, false)
sel_spd = img_add("Gi-275 attitude overlay spd.PNG", 0, 4, 320, 320)
visible(sel_spd, false)
sel_alt = img_add("Gi-275 attitude overlay alt.PNG", 0, 4, 320, 320)
visible(sel_alt, false)
alt_alert_img = img_add("Gi-275 attitude alt alert.png", 0, 0, 320, 320)
visible(alt_alert_img, false) -- Hide by default
baro_txt_overlay = txt_add("", "size:15; font:arimo_bold.ttf; color:#00eaff; halign:center; valign:center", 220, 201, 83, 34)
hdg_txt_overlay = txt_add("", "size:15; font:arimo_bold.ttf; color:#00eaff; halign:center; valign:center", 15, 202, 83, 34)
alt_txt_overlay = txt_add("", "size:15; font:arimo_bold.ttf; color:#00eaff; halign:right; valign:center", 185, 55, 83, 34)
spd_txt_overlay = txt_add("", "size:15; font:arimo_bold.ttf; color:#00eaff; halign:center; valign:center", 30, 55, 84, 34)
vs_txt_overlay = txt_add("", "size:15; font:arimo_bold.ttf; color:white; halign:right; valign:center", 235, 165, 34, 34)
-- Mode text overlay handles (for Air Manager txt_add)
lateral_mode_txt = txt_add("", "size:17; font:arimo_bold.ttf; color:green; halign:center; valign:center", mode_lateral_x, mode_bar_y, 44, mode_bar_h)
ap_mode_txt = txt_add("", "size:17; font:arimo_bold.ttf; color:green; halign:center; valign:center", mode_ap_x, mode_bar_y, 54, mode_bar_h)
pitch_mode_txt = txt_add("", "size:17; font:arimo_bold.ttf; color:green; halign:center; valign:center", mode_pitch_x, mode_bar_y, 55, mode_bar_h)
armed_lateral_mode_txt  = txt_add("", "size:17; font:arimo_bold.ttf; color:white; halign:center; valign:center", armed_lateral_x, mode_bar_y, 44, mode_bar_h)
armed_pitch_mode_txt    = txt_add("", "size:17; font:arimo_bold.ttf; color:white; halign:center; valign:center", armed_pitch_x, mode_bar_y, 44, mode_bar_h)


foreground_img = img_add("Gi-275 attitude bezel.png", 0, 0, 320, 320)

knob_outer = dial_add("rotary_outer.png", 5, 258, 60,60, dial_out)
knob_inner = dial_add("knob_inner.png", 15, 270, 40, 40, dial_in)
button = button_add(nil, nil, 20, 270, 20, 20, button_pressed)

-- At top-level (not inside any function)
--alert_timer_handle = timer_start(0, 0.1, function() alerting_timer_tick(0.1) end)
function do_timer()
    timer_cnt = timer_cnt + 1
    -- Toggle flash_state if alert_timer > 0
    if alert_timer > 0 then
        flash_state = not flash_state
    else
        flash_state = false
    end
    refresh()
    alerting_timer_tick(0.1)    -- << Correct interval, not count
    update_trend_predictions()
end

timer_start(0, 100, do_timer)   -- << 100 ms interval for proper flashing

