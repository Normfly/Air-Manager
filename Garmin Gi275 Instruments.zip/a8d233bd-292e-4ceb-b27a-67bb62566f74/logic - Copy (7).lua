-- Air Manager GI-275 Attitude Indicator (AM Canvas API) with Heading Arc, Airspeed Tape, Altitude Tape, and Horizontal Heading Tape

local W, H = 320, 320
local TEST_MODE = true

local vS = 43
local vS0 = 36
local vFE = 88
local vNE = 150
local red_max = 300

local sky = "deepskyblue"
local ground = "#b8865b"
local white = "white"
local black = "black"
local yellow = "#f2e200"
local magenta = "#e049b0"
local orange = "#fa8a00"
local dark_grey = "#404040"
local red = "#ff0000"
local green = "#00ff00"
local cyan = "#00eaff"

local sel = 0 -- 0 none, 1 baro, 2 hdg, 3 spd, 4 alt

local pitch, bank, heading = 0, 0, 0
local ias = 0
local altitude = 0
local baro_setting = 29.92 -- default baro inHg

local horizon_img = img_add("horizon.png", -160, -160, 640, 640)  -- 640x640 image centered over 320x320 gauge

-- Bugs
local airspeed_bug = 110
local altitude_bug = 200
local heading_bug = 10

function dial_out(dir)
    if sel == 1 then -- baro
        local step = 0.01
        baro_setting = baro_setting + (dir > 0 and step or -step)
        -- Clamp to valid range, e.g. 28.00 to 31.00
        if baro_setting < 28.00 then baro_setting = 28.00 end
        if baro_setting > 31.00 then baro_setting = 31.00 end
    end
    print(baro_setting)
    refresh()
end

function dial_in(dir)
    print("inner")
end

function button_pressed()
    print("pressed")
end

-- Draw chevron bug with filled color and black outline
function draw_chevron_bug(x, y, width, height, rotation_deg)
    local fill_color = "#82e4ea"
    local stroke_color = "black"
    local stroke_thickness = 2

    -- Flat-left, double-hump-right chevron
    local left = -width/2
    local right = width/2

    -- Make the middle "nose" closer to the flat side by reducing its x value
    local mid_right_x = left + 0.4 * width
    local mid_right_y = 0

    local top_hump_x = right * 0.9
    local top_hump_y = -height/2
    local bot_hump_x = right * 0.9
    local bot_hump_y = height/2

    local shape = {
        {left, -height/2},         -- Top left (flat)
        {top_hump_x, top_hump_y},  -- Top hump
        {mid_right_x, mid_right_y},-- Middle "nose", closer to flat side
        {bot_hump_x, bot_hump_y},  -- Bottom hump
        {left, height/2},          -- Bottom left (flat)
    }

    -- Rotation function
    local function rotate_point(px, py, angle_rad)
        local cos_a = math.cos(angle_rad)
        local sin_a = math.sin(angle_rad)
        return px * cos_a - py * sin_a, px * sin_a + py * cos_a
    end

    local angle_rad = math.rad(rotation_deg or 0)
    local pts = {}
    for i, pt in ipairs(shape) do
        local rx, ry = rotate_point(pt[1], pt[2], angle_rad)
        pts[i] = {x + rx, y + ry}
    end

    -- Draw filled polygon
    _move_to(pts[1][1], pts[1][2])
    for i = 2, #pts do
        _line_to(pts[i][1], pts[i][2])
    end
    _fill(fill_color)

    -- Draw outline in black
    _move_to(pts[1][1], pts[1][2])
    for i = 2, #pts do
        _line_to(pts[i][1], pts[i][2])
    end
    _line_to(pts[1][1], pts[1][2])
    _stroke(stroke_color, stroke_thickness)
end

function draw_horizon(pitch, bank)
    local cx, cy = W / 2, H / 2
    local radius = W / 2
    local pitch_range = 40
    local px_per_deg = 320 / pitch_range

    local horizon_offset_y = -12  -- move horizon

    local y_offset = pitch * px_per_deg

    if canvas_clip_circle then
        canvas_clip_circle(cx, cy + horizon_offset_y, radius)
    end

    img_move(horizon_img, -160, -160 + y_offset + horizon_offset_y, 640, 640)
    img_rotate(horizon_img, -bank)

    local pitch_clip_top = cy + horizon_offset_y - 10 * px_per_deg + y_offset
    local pitch_clip_bot = cy + horizon_offset_y + 10 * px_per_deg + y_offset

    for i = -pitch_range + 20, pitch_range - 20, 2.5 do
        if i ~= 0 then
            local yp = cy + horizon_offset_y + y_offset + i * px_per_deg
            if yp >= pitch_clip_top and yp <= pitch_clip_bot then
                local is10 = math.abs(i) % 10 == 0
                local is5 = not is10 and math.abs(i) % 5 == 0

                local len = is10 and 60 or (is5 and 30 or 15)
                local thickness = is10 and 4 or (is5 and 2 or 1)
                local color = white

                _move_to(cx - len, yp)
                _line_to(cx + len, yp)
                _stroke(color, thickness)

                if is10 or is5 then
                    local txt_val = tostring(-i)
                    local txt_size = is10 and "size:18; font:arimo_bold.ttf; color:white" or "size:14; font:Open Sans; color:white"
                    _txt(txt_val, txt_size, cx - len - 24, yp - 10)
                    _txt(txt_val, txt_size, cx + len + 4, yp - 10)
                end
            end
        end
    end
end

function draw_bank()
    local y_clip = 75

    local cx, cy = 160, 220
    local radius = 200
    local arc_start = -90
    local arc_end = 90

    for ang = arc_start, arc_end, 10 do
        local a = math.rad(ang - bank)
        local is_major = ang % 30 == 0

        local tick_in = is_major and 12 or 8
        local tick_out = is_major and 14 or 10
        local tick_width = is_major and 4 or 2

        local x1 = cx + (radius - tick_in) * math.sin(a)
        local y1 = cy - (radius - tick_in) * math.cos(a)
        local x2 = cx + (radius + tick_out) * math.sin(a)
        local y2 = cy - (radius + tick_out) * math.cos(a)
        if y1 < y_clip and y2 < y_clip then
            _move_to(x1, y1)
            _line_to(x2, y2)
            _stroke(white, tick_width)
        end
    end

    local airplane_angles = {-12, 12}
    local y_top = 5
    local airplane_radius = cy - y_top
    local airplane_fuselage = 13
    local airplane_wing = 10

    for _, ang_offset in ipairs(airplane_angles) do
        local a = math.rad(ang_offset - bank)
        local ax = cx + airplane_radius * math.sin(a)
        local ay = cy - airplane_radius * math.cos(a)
        if ay < y_clip then
            _move_to(ax, ay - airplane_fuselage/2)
            _line_to(ax, ay + airplane_fuselage/2)
            _stroke(white, 2.5)
            _move_to(ax - airplane_wing/2, ay)
            _line_to(ax + airplane_wing/2, ay)
            _stroke(white, 2.5)
        end
    end

    local tri_w = 20
    local tri_h = 30
    local tri_radius = airplane_radius
    local tri_angle = math.rad(-bank)

    local tri_pts = {
        {0, tri_h},
        {-tri_w/2, 0},
        {tri_w/2, 0},
    }

    local tri_cx = cx + tri_radius * math.sin(tri_angle)
    local tri_cy = cy - tri_radius * math.cos(tri_angle)

    local function rotate(x, y, theta)
        local cos_t = math.cos(theta)
        local sin_t = math.sin(theta)
        return x * cos_t - y * sin_t, x * sin_t + y * cos_t
    end

    local tri_rot = math.rad(-bank)
    local px1, py1 = rotate(tri_pts[1][1], tri_pts[1][2], tri_rot)
    local px2, py2 = rotate(tri_pts[2][1], tri_pts[2][2], tri_rot)
    local px3, py3 = rotate(tri_pts[3][1], tri_pts[3][2], tri_rot)

    px1 = px1 + tri_cx; py1 = py1 + tri_cy
    px2 = px2 + tri_cx; py2 = py2 + tri_cy
    px3 = px3 + tri_cx; py3 = py3 + tri_cy

    if py1 < y_clip and py2 < y_clip and py3 < y_clip then
        _triangle(px1, py1, px2, py2, px3, py3)
        _fill(white)
    end
end

function draw_speed_band_arc(cx, cy, r, min_speed, max_speed, band_start, band_end, arc_start, arc_end, width, x_offset, color)
    local s1 = math.max(band_start, min_speed)
    local s2 = math.min(band_end, max_speed)
    if s2 <= s1 then return end

    local function speed_to_angle(speed)
        local frac = (speed - min_speed) / (max_speed - min_speed)
        return arc_start + frac * (arc_end - arc_start)
    end

    local a1 = speed_to_angle(s1)
    local a2 = speed_to_angle(s2)
    a1 = math.max(a1, arc_start)
    a2 = math.min(a2, arc_end)
    if a2 <= a1 then return end

    local steps = 80
    local pts = {}
    for i = 0, steps do
        local frac = i / steps
        local ang = math.rad(a1 + frac * (a2 - a1))
        local x = cx + (r - width/2) * math.cos(ang) + x_offset
        local y = cy + (r - width/2) * math.sin(ang)
        table.insert(pts, {x, y})
    end
    for i = steps, 0, -1 do
        local frac = i / steps
        local ang = math.rad(a1 + frac * (a2 - a1))
        local x = cx + (r + width/2) * math.cos(ang) + x_offset
        local y = cy + (r + width/2) * math.sin(ang)
        table.insert(pts, {x, y})
    end

    _move_to(pts[1][1], pts[1][2])
    for i = 2, #pts do
        _line_to(pts[i][1], pts[i][2])
    end
    _fill(color)
end

function draw_airspeed_tape(ias)
    local tape_left = 10
    local tape_top = 30
    local tape_height = 260
    local tape_width = 40

    local knots_step_major = 10
    local knots_step_minor = 5
    local knots_span = 60
    local knots_top = math.floor(ias / knots_step_major) * knots_step_major + 30
    local knots_bot = knots_top - knots_span

    local tape_radius = 135
    local arc_start = 140
    local arc_end = 220

    draw_speed_band_arc(160, 160, tape_radius, knots_bot, knots_top, vS, vNE, arc_start, arc_end, 16, 0, green)
    draw_speed_band_arc(160, 160, tape_radius, knots_bot, knots_top, vNE, red_max, arc_start, arc_end, 16, 0, red)
    draw_speed_band_arc(160, 160, tape_radius - 22, knots_bot, knots_top, vS0, vFE, arc_start, arc_end, 10, -25, white)

    local offset_x = -10
    local tick_inner = tape_radius - 18
    local tick_outer_major = tape_radius + 8   -- length for major ticks (10 knots)
    local tick_outer_minor = tape_radius + 3   -- length for minor ticks (5 knots)
    local cx, cy = 160, 160

    -- Draw ticks and scrolling airspeed text at each major tick
    local tick_length_major = 15   -- major tick (10 knots)
    local tick_length_minor = 10   -- minor tick (5 knots)

    for k = knots_bot, knots_top, knots_step_minor do
        local frac = (k - knots_bot) / (knots_top - knots_bot)
        local angle_deg = arc_start + frac * (arc_end - arc_start)
        local angle = math.rad(angle_deg)
        local is_major = (k % knots_step_major == 0)

        local tick_length = is_major and tick_length_major or tick_length_minor
        local tick_thick = is_major and 3 or 1.5

        -- Shift minor ticks further left (start them further in)
        local tick_start = tick_inner + (is_major and 0 or (tick_length_major - tick_length_minor))
        local x1 = cx + tick_start * math.cos(angle) + offset_x
        local y1 = cy + tick_start * math.sin(angle)
        local x2 = cx + (tick_inner + tick_length_major) * math.cos(angle) + offset_x
        local y2 = cy + (tick_inner + tick_length_major) * math.sin(angle)
        _move_to(x1, y1)
        _line_to(x2, y2)
        _stroke("white", tick_thick)

        if is_major then
            local label_x = x2 + 25
            local label_y = y2 - 12
            _txt(
                tostring(k),
                "size:22; font:arimo_bold.ttf; color:white; align:right",
                label_x, label_y, 44, 28
            )
        end
    end

    -- draw current airspeed
    draw_current_ias(54, 160, 60)
    _txt(string.format("%d", math.floor(ias)), "size:25; font:arimo_bold.ttf; color:white", 30, 148)

    draw_airspeed_bug(airspeed_bug, knots_bot, knots_top, tape_radius, arc_start, arc_end)
end

function draw_current_ias(x, y, size)
    local shape = {
        {-0.7, 0},
        {-0.41, -0.15},
        {-0.41, -0.222},
        {0.47, -0.222},
        {0.47, -0.072},
        {0.65, -0.072},
        {0.65,  0.072},
        {0.47,  0.072},
        {0.47,  0.222},
        {-0.41,  0.222},
        {-0.41,  0.15},
        {-0.7, 0},
    }
    local pts = {}
    for i, pt in ipairs(shape) do
        pts[i] = {x + pt[1]*size, y + pt[2]*size}
    end
    _move_to(pts[1][1], pts[1][2])
    for i = 2, #pts do
        _line_to(pts[i][1], pts[i][2])
    end
    _stroke("white", 2)
    for i = 2, #pts-1 do
        _triangle(pts[1][1], pts[1][2],
                  pts[i][1], pts[i][2],
                  pts[i+1][1], pts[i+1][2])
        _fill("black")
    end
end

function draw_airspeed_bug(bug_speed, knots_bot, knots_top, tape_radius, arc_start, arc_end)
    if bug_speed < knots_bot or bug_speed > knots_top then return end

    local cx, cy = 160, 160
    local bug_radius = tape_radius + 16

    local frac = (bug_speed - knots_bot) / (knots_top - knots_bot)
    local angle_deg = arc_start + frac * (arc_end - arc_start)
    local angle_rad = math.rad(angle_deg)

    local bug_x = cx + bug_radius * math.cos(angle_rad)
    local bug_y = cy + bug_radius * math.sin(angle_rad)

    -- Chevron tip points inward; tweak offset for perfect placement
    draw_chevron_bug(bug_x+10, bug_y, 15, 25, angle_deg + 180)
end

function draw_altitude_tape(altitude)
    local tape_radius = 135
    local cx, cy = 160, 160
    local offset_x = 10 -- horizontal offset for tape
    local arc_start = 40
    local arc_end = -40

    local step_major = 100
    local step_minor = 50
    local span = 600

    -- Center the tape on current altitude
    local alt_center = math.floor(altitude / step_major) * step_major
    local alt_bot = alt_center - span / 2
    local alt_top = alt_center + span / 2

    local tick_inner = tape_radius - 20
    local tick_outer_major = tape_radius + 8
    local tick_outer_minor = tape_radius + 3

    for k = alt_bot, alt_top, step_minor do
        local frac = (k - alt_bot) / (alt_top - alt_bot)
        local angle_deg = arc_start + frac * (arc_end - arc_start)
        local angle = math.rad(angle_deg)
        local is_hundred = (k % 100 == 0)
        local tick_out = is_hundred and tick_outer_major or tick_outer_minor
        local tick_thick = is_hundred and 3 or 1.5

        local x1 = cx + tick_inner * math.cos(angle) + offset_x
        local y1 = cy + tick_inner * math.sin(angle)
        local x2 = cx + tick_out * math.cos(angle) + offset_x
        local y2 = cy + tick_out * math.sin(angle)
        _move_to(x1, y1)
        _line_to(x2, y2)
        _stroke("white", tick_thick)

        if is_hundred then
            local alt_txt_thousand = math.floor(k / 1000)
            local alt_txt_hundred = math.floor((k % 1000) / 100)
            local label_x = x2 - 50
            local label_y = y2 + 6 -- Lowered label for better alignment

            if alt_txt_thousand > 0 then
                _txt(
                    tostring(alt_txt_thousand),
                    "size:22; font:arimo_bold.ttf; color:white; align:left",
                    label_x, label_y, 20, 20
                )
                _txt(
                    tostring(alt_txt_hundred),
                    "size:14; font:arimo_bold.ttf; color:white; align:left",
                    label_x + 10, label_y + 12, 14, 14 -- Lowered hundreds digit
                )
            else
                _txt(
                    tostring(alt_txt_hundred),
                    "size:18; font:arimo_bold.ttf; color:white; align:left",
                    label_x, label_y, 18, 18
                )
            end
        end
    end

    local arrow_x = W - 40
    local arrow_y = 160
    draw_current_altitude(arrow_x, arrow_y, 50)
    
    draw_altitude_bug_arc(altitude_bug, alt_bot, alt_top, tape_radius, arc_start, arc_end, offset_x)
end

function draw_current_altitude(x, y, size)
    local offset_x = -10

    local shape_width = 0.7

    local shape = {
        {0.9 * shape_width, 0},
        {0.53 * shape_width, -0.15},
        {0.53 * shape_width, -0.222},
        {-0.60 * shape_width, -0.222},
        {-0.60 * shape_width, -0.072},
        {-0.85 * shape_width, -0.072},
        {-0.85 * shape_width, 0.072},
        {-0.60 * shape_width, 0.072},
        {-0.60 * shape_width, 0.222},
        {0.53 * shape_width, 0.222},
        {0.53 * shape_width, 0.15},
        {0.9 * shape_width, 0},
    }
    local pts = {}
    for i, pt in ipairs(shape) do
        pts[i] = {x + pt[1]*size + offset_x, y + pt[2]*size}
    end
    _move_to(pts[1][1], pts[1][2])
    for i = 2, #pts do
        _line_to(pts[i][1], pts[i][2])
    end
    _stroke("white", 2)
    for i = 2, #pts-1 do
        _triangle(pts[1][1], pts[1][2],
                  pts[i][1], pts[i][2],
                  pts[i+1][1], pts[i+1][2])
        _fill("black")
    end

    _txt(
        string.format("%d", math.floor(altitude)),
        "size:20; font:arimo_bold.ttf; color:white; halign:right",
        W-15 + offset_x, 149, 50, 26 )
end

function draw_altitude_bug_arc(bug_alt, alt_bot, alt_top, tape_radius, arc_start, arc_end, offset_x)
    if bug_alt < alt_bot or bug_alt > alt_top then
        return
    end
    local cx, cy = 160, 160
    local bug_radius = tape_radius + 18
    local frac = (bug_alt - alt_bot) / (alt_top - alt_bot)
    local angle_deg = arc_start + frac * (arc_end - arc_start)
    local angle_rad = math.rad(angle_deg)
    local bug_x = cx + bug_radius * math.cos(angle_rad) + offset_x
    local bug_y = cy + bug_radius * math.sin(angle_rad)
    draw_chevron_bug(bug_x-25, bug_y-2, 15, 24, angle_deg + 180)
end

function heading_to_text(val)
    val = math.floor(val + 0.5) % 360
    if val == 0 then
        return " N"
    elseif val == 90 then
        return " E"
    elseif val == 180 then
        return " S"
    elseif val == 270 then
        return " W"
    else
        return string.format("%03d", val)
    end
end

function draw_heading_bug(hdg_center, tape_left, tape_bottom, tape_width, tape_height)
    local span = 60
    local bug_diff = ((heading_bug - hdg_center + 540) % 360) - 180
    if math.abs(bug_diff) > span/2 then
        return
    end
    local frac = bug_diff / span
    local bug_x = tape_left + tape_width/2 + frac * tape_width
    local bug_y = tape_bottom - tape_height/2 - 8
    draw_chevron_bug(bug_x, bug_y+20, 15, 25, 90)
end

function draw_heading_tape(hdg)
    local tape_left = 35
    local tape_bottom = H - 65
    local tape_width = W - 70
    local tape_height = 40

    local span = 60
    local deg_step_major = 10
    local deg_step_minor = 5

    local hdg_center = hdg % 360

    _rect(tape_left, tape_bottom - tape_height/2, tape_width, tape_height, 8)
    _fill(black)

    for d = -span/2, span/2, deg_step_minor do
        local hdg_tick = (hdg_center + d + 360) % 360
        local x = tape_left + tape_width/2 + (d / span) * tape_width

        local is_major = d % deg_step_major == 0
        local is_label = (hdg_tick % 30 == 0) or (hdg_tick == 0)

        if x > tape_left and x < tape_left + tape_width then
            if is_major then
                _move_to(x, tape_bottom - tape_height/2 + 6)
                _line_to(x, tape_bottom + tape_height/2 - 6)
                _stroke(white, 3)

                if is_label then
                    local heading_text = heading_to_text(hdg_tick)
                    local label_w = 32
                    local label_h = 22
                    local box_pad = 6
                    local box_w = label_w + box_pad
                    local box_h = label_h
                    local box_x = x - box_w/2
                    local box_y = tape_bottom - tape_height/2 + 15

                    _rect(box_x, box_y, box_w, box_h, 6)
                    _fill(black)
                    _txt(heading_text, "size:22; font:arimo_bold.ttf; color:white; align:center",
                         x - label_w/2 + 5, box_y, label_w, label_h)
                end
            else
                _move_to(x, tape_bottom - 7)
                _line_to(x, tape_bottom + 7)
                _stroke(white, 2)
            end
        end
    end

    local pointer_x = tape_left + tape_width/2
    local box_w = 44
    local box_h = 28
    local box_y = (tape_bottom - tape_height/2) + 15

    _rect(pointer_x - box_w/2, box_y, box_w, box_h, 7)
    _fill(black)
    local hdg_val = math.floor(hdg_center + 0.5) % 360
    local hdg_num = hdg_val == 0 and "360" or string.format("%03d", hdg_val)
    _txt(hdg_num, "size:22; font:arimo_bold.ttf; color:white; align:center",
         pointer_x - box_w/2 + 5, box_y + 2, box_w, box_h - 2)

    draw_heading_bug(hdg_center, tape_left, tape_bottom, tape_width, tape_height)
end

function update_baro_display()
    local s_baro = baro_setting .. "in"
    txt_set(baro_txt_overlay, s_baro)
    -- Always visible, don't hide
end

function redraw()
    
    if canvas_clip_circle then
        canvas_clip_circle(W/2, H/2, W/2-2)
    end
    draw_horizon(pitch, bank)
    draw_bank()
    draw_airspeed_tape(ias)
    draw_altitude_tape(altitude)
    draw_heading_tape(heading)

    if (baro_txt_overlay)then
        update_baro_display()
        
        visible(foreground_img, true)
    
        if sel == 0 then
            visible(sel_baro, false)
            visible(sel_hdg, false)
            visible(sel_spd, false)
            visible(sel_alt, false)
        elseif sel == 1 then
            visible(sel_baro, true)
            visible(sel_hdg, false)
            visible(sel_spd, false)
            visible(sel_alt, false)
        elseif sel == 2 then
            visible(sel_hdg, true)
            visible(sel_baro, false)
            visible(sel_spd, false)
            visible(sel_alt, false)
        elseif sel == 3 then
            visible(sel_spd, true)
            visible(sel_baro, false)
            visible(sel_hdg, false)
            visible(sel_alt, false)
        elseif sel == 4 then
            visible(sel_alt, true)
            visible(sel_baro, false)
            visible(sel_hdg, false)
            visible(sel_spd, false)
        end
    end
    
end


function refresh()
    canvas_draw(canvas_id, function() redraw() end)
end

function new_attitude(p, b, h, a, baro)
    pitch, bank, heading, altitude = p, b, h, a
    baro_setting = baro
    refresh()
end

if TEST_MODE then
    local t = 0
    function test_anim()
        t = t + 0.05
        local fake_pitch = 0
        local fake_bank = 0
        local fake_heading = 350
        local fake_ias = 110
        local fake_altitude = 200
        ias = fake_ias
        altitude = fake_altitude
        new_attitude(fake_pitch, fake_bank, fake_heading, fake_altitude, baro_setting)
    end
    timer_start(0, 0.03, test_anim)
else
    fs2020_variable_subscribe(
        "PLANE PITCH DEGREES", "Degrees",
        "PLANE BANK DEGREES", "Degrees",
        "PLANE HEADING DEGREES TRUE", "Degrees",
        "AIRSPEED INDICATED", "Knots",
        "INDICATED ALTITUDE", "Feet",
        "KOHLSMAN SETTING HG", "Inches of Mercury",
        function(p, b, h, s, a, baro)
            pitch, bank, heading, ias, altitude, baro_setting = p, b, h, s, a, baro
            if canvas_id then
                refresh()
            end
            
        end
    )
end

--init
-- knobs and button
knob_outer = dial_add("rotary_outer.png", 5, 255, 60,60, dial_out)
knob_inner = dial_add("knob_inner.png", 15, 265, 40, 40, dial_in)
button = button_add(nil, nil, 20, 270, 20, 20, button_pressed)

-- Bottom right (Baro bug) -- sel = 1
button_baro = button_add(nil, nil, 232, 200, 70, 32, function()
    sel = 1
    if canvas_id then
        refresh()
    end
end)
-- Bottom left (Heading bug) -- sel = 2
button_heading = button_add(nil, nil, 24, 200, 54, 32, function()
    sel = 2
    if canvas_id then
        refresh()
    end
end)
-- Top left (Airspeed bug) -- sel = 3
button_airspeed = button_add(nil, nil, 24, 60, 54, 32, function()
    sel = 3
    if canvas_id then
        refresh()
    end
end)
-- Top right (Altitude bug) -- sel = 4
button_altitude = button_add(nil, nil, 242, 60, 54, 32, function()
    sel = 4
    if canvas_id then
        refresh()
    end
end)

canvas_id = canvas_add(0, 0, W, H, function()
    redraw()
end)

foreground_img = img_add("Gi-275 attitude overlay.png", 0, 0, 320, 320)
sel_baro = img_add("Gi-275 attitude overlay baro.PNG", 0, 0, 320, 320)
visible(sel_baro, false)
sel_hdg = img_add("Gi-275 attitude overlay hdg.PNG", 0, 0, 320, 320)
visible(sel_hdg, false)
sel_spd = img_add("Gi-275 attitude overlay spd.PNG", 0, 0, 320, 320)
visible(sel_spd, false)
sel_alt = img_add("Gi-275 attitude overlay alt.PNG", 0, 0, 320, 320)
visible(sel_alt, false)
baro_txt_overlay = txt_add("", "size:15; font:arimo_bold.ttf; color:#00eaff; halign:center; valign:center", 220, 199, 83, 34)
foreground_img = img_add("Gi-275 attitude bezel.png", 0, 0, 320, 320)


